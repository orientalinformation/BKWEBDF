@if(!empty($data->count()))
<section class="service mt-5 mb-5">
    <div class="container">
        <h2 class="text-uppercase title-name">@lang('frontend.title.service')</h2>

        <h2 class="title mb-0">
            @lang('frontend.title.sub_title_service')
        </h2>

        <p>@lang('frontend.title.service_des')</p>

        <div class="row mt-5">
            @foreach($data as $index => $item)
            @php( $item = $item->translate() )
            @if(blank($item->title)) @continue  @endif
            <div class="col-md-4 col-sm-12" style="margin-bottom: 40px">
                <div class="service-tittle mb-5 service-icon{{$index + 1}}" >
                    <div class="service-name">
                        <span>{{ "0".($index + 1) }}</span>
                        <p class="mt-3 text-truncate">{{$item->title}}</p>
                    </div>
                </div>
                <div class="service-content" style="height: 220px">
                    <p>
                        {!! $item->description !!}
                    </p>
                </div>
                <div class="text-center">
                    <a href="{{ route('service.getDetail', $item->slug) }}" class="btn btn-seen">@lang('frontend.button.btn_more')</a>

                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@endif