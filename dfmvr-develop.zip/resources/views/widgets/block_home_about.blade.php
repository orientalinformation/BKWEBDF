@if(!empty($data) )
<section class="introduce mt-5 mb-5">
    <div class="container">
        <h2 class="text-uppercase title-name">@lang('frontend.title.about')</h2>
        <p class="title">
            {!! $data->translate()->excerpt !!}
        </p>
        <div class="row">
            <div class="col-lg-6">
                <p class="content ">
                    {!! $data->translate()->body !!}
                </p>
                <div class="text-center">
                    <a class="btn btn-seen" href="{{ route('page.index', 'introduce') }}">@lang('frontend.button.btn_more')</a>
                </div>
            </div>
            <div class="col-lg-6 text-center">
                <img src="{{ $data->image ? Voyager::image($data->image) : asset('frontend/images/banner/introduce1.png') }}" alt="{{ $data->translate()->title}} " width="90%" height="90%">
            </div>
        </div>
    </div>
</section>
@endif
