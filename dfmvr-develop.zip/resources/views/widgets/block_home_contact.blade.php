@inject('service', App\Services\ServiceService)

<section class="contact mt-5">
    <div class="content container">
        @if( url()->current() == route('index') )
        <h2 class="text-uppercase title-name">@lang('frontend.title.contact')</h2>
        @endif
        <div class="row">
            <div class="col-md-8 border-right contact-form-dfm">
                <h3 class="title mb-0">
                    @lang('frontend.title.sub_title_contact1')
                {{--     <a href="tel:{{ $service->phoneTranslate() }}">
                        <span>{{ $service->phoneTranslate() }}</span>
                    </a> --}}
                </h3>
                <div class="mt-1 fix-phonecss">@lang('frontend.title.sub_title_contact2')
                    <a href="mailto: {{ $service->emailTranslate() }}">
                        <span>{{ $service->emailTranslate() }}</span>
                    </a>
                    <span>@lang('frontend.title.or_telephone')</span>
                    <a href="tel:{{ $service->phoneTranslate() }}">
                        <span>{{ $service->phoneTranslate() }}</span>
                    </a>
                </div>
                <div class="container">
                    <form action="{{ route('contact') }}" method="POST" id="id_contact">
                        @csrf
                        <div class="form-group row">
                            <div class="col-md-6">
                                <input type="text" name="name" placeholder="{!! trans('frontend.placeholder.contact_name') !!}" class="form-control" required>
                                <div id="validate_name" class="text-danger"> </div>
                            </div>
                            <div class="col-md-6">
                                <input type="email" name="email" placeholder="{!! trans('frontend.placeholder.contact_email') !!}" class="form-control" required>
                                <div id="validate_email" class="text-danger"> </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <input type="text" name="phone" placeholder="{!! trans('frontend.placeholder.contact_tel') !!}" class="form-control" required>
                                <div id="validate_tel" class="text-danger"> </div>
                            </div>
                            <div class="col-md-6">
                                <select name="field" class="form-control" required>
                                    <option value="">{!! trans('frontend.placeholder.contact_field') !!}</option>
                                    <option value="vr">@lang('contacts.select.vr')</option>
                                    <option value="ar">@lang('contacts.select.ar')</option>
                                    <option value="other">@lang('contacts.select.other')</option>
                                </select>
                                <div id="validate_field" class="text-danger"> </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12">
                                <textarea class="form-control" name="message" id="exampleFormControlTextarea1" placeholder="{!! trans('frontend.placeholder.contact_content') !!}" rows="10" required></textarea>
                                <div id="validate_content" class="text-danger"> </div>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <div class="col-md-6">
                                
                                {!! NoCaptcha::renderJs() !!}
                                {!! NoCaptcha::display() !!}

                                <div id="captcha2" class="text-danger"> </div>      
                            </div>
                            <div class="col-md-6 text-right mx-auto">
                                <button class="btn btn-seen" type="submit">@lang('frontend.placeholder.contact_confirm')</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <div class="contact-dfm">
                    <h5>Dfm Europe</h5>
                    <ul>
                        <li>
                            {{ setting('site.address_fr') }}
                        </li>
                        <li>
                            {{ setting('site.email_fr') }}
                        </li>
                        <li>
                            {{ setting('site.tel_fr') }}
                        </li>
                    </ul>
                </div>
                <div class="contact-dfm">
                    <h5>Dfm Engineering</h5>
                    <ul>
                        <li>
                            {{ setting('site.address') }}
                        </li>
                        <li>
                            {{ setting('site.email') }}
                        </li>
                        <li>
                            {{ setting('site.tel') }}
                        </li>
                    </ul>
                </div>
                <div class="contact-dfm">
                    <h5>@lang('contacts.media.title')</h5>
                    <a href="{{ setting('site.youtube') }}" class="text-dfmvr"><i class="fa fa-3x fa-youtube-play" aria-hidden="true"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>

@push('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script>
    $(document).ready(function($) {
        $('#id_contact').on('submit', function(e) {
            e.preventDefault();

            var url = $(this).attr('action');
            console.log(url);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('input[name="_token"]').attr('value')
                }
            });
            $.ajax({
                type: 'POST',
                url: url,
                data: new FormData(this),
                cache: false,
                contentType: false,
                processData: false,
                success: function(data) {
                    if (data.error == 1) {
                        // toastr.error(data.message);
                        $('#captcha2').text(data.message);
                    } else {
                        toastr.success(data.message);
                        document.getElementById("id_contact").reset();
                    }
                },
                error: function(xhr, status, errors) {
                    toastr.error('Erros !!!');
                },
            });
        });

    });
</script>

@endpush