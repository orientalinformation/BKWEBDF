@if(!empty($data->count()))
<section class="news mt-5">
    <div class="content container">
        <div class="row m-0">
            <h4 class="text-uppercase title-name col-md-6 col-sm-6 col-6">@lang('frontend.title.news')</h4>
            <div class="controls-top col-md-6 col-sm-6 col-6 d-flex flex-row-reverse">
                <a class="btn-floating mr-2" href="#carousel-example-multi" data-slide="next">
                    <i class="fa fa-angle-right" aria-hidden="true"></i>
                </a>
                <a class="btn-floating ml-2" href="#carousel-example-multi" data-slide="prev">
                    <i class="fa fa-angle-left" aria-hidden="true"></i>
                </a>
            </div>
        </div>
        <div class="mt-5">
        <div id="carousel-example-multi" class="carousel slide carousel-multi-item v-2" data-ride="carousel" data-interval="2500">
            <div class="row carousel-inner v-2 m-0" role="listbox">
                @foreach($data as $i => $item_img)
                @php( $item = $item_img->translate() )
                @if(blank($item->title)) @continue  @endif
                <div class="carousel-item {{ $i == 0 ? "active" : "" }}">
                    <div class="col-12 col-md-3 col-sm-6">
                        <div class="card mb-2">
                            <a href="{{ route('news.detail', $item->slug)}}">
                                <img class="card-img-top" src="{{ $item_img->image ? Voyager::image($item_img->thumbnail('cropped')) : $item_img->defaultThumb() }}" alt="{{ $item->title }}"/>
                            </a>
                            <div class="card-body">
                                
                                <h4 class="card-title "><a href="{{ route('news.detail', $item->slug)}}">{{ $item->title }}</a></h4>

                                <span class="cus-time">{{ $item->created_at }}</span>
                                
                                <p class="service-content ">
                                {!! str_limit(strip_tags($item->content), 220) !!}
                                </p>

                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</section>
@endif
