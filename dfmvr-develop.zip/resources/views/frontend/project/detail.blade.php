@extends('layouts.frontend')

@include('frontend.include.meta_seo', ['model' => $project])

@section('content')

@php ( $project = $project->translate() )
<section>
    <div class="container p-detail-project">
        <div class="detail-project-content">
            <h1 class="text-uppercase mt-5">{{ $project->title }}</h1>
            <span class="time">{{ $project->created_at }}</span>
            <div class="mt-5 responsive-img">
                {!! $project->content !!}
            </div>
        </div>
        <div class="sub-menu mt-5">
            <div class="container">
                <nav class="navbar navbar-expand-lg navbar-light bg-light menu">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            @foreach($categories as $item)
                            @php ( $item = $item->translate() )
                            @if(blank($item->name)) @continue  @endif
                            <li class="nav-item item-menu {{ $item->id == $project->category_id ? 'active' : ''}}">
                                <a class="nav-link" href="{{ route('project.category', $item->slug) }}">{{ $item->name }}</a>
                            </li>
                            @endforeach()
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </div>
</section>

@endsection