@inject('imageService', App\Services\ImageService)

@extends('layouts.frontend')

@include('frontend.include.meta_seo', ['model' => null, 'type' => 'project'])

@section('content')

<section class="project-content">
    <div class="container">
        <div class="text-center title">
            @lang('frontend.title.sub_title_project')
        </div>
  {{--       <div class="sub-menu">
            <div class="container">
                <nav class="navbar navbar-expand-lg navbar-light bg-light menu">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            @foreach($categories as $item)
                            @php ( $item = $item->translate() )
                            @if(blank($item->name)) @continue  @endif
                            <li class="nav-item item-menu {{ url()->current() == route('project.category', $item->slug) ? 'active' : ''}}">
                                <a class="nav-link" href="{{ route('project.category', $item->slug) }}">{{ $item->name }}</a>
                            </li>
                            @endforeach
                        </ul>
                    </div>
                </nav>
            </div>
        </div> --}}

        <!-- END CATEGORIES-->

        <div class="style-tags">
            <div class="tag-content">
                <a href="{{ route('project.index') }}" class="tag_item badge {{ url()->current() == route('project.index') ? 'active' : ''}}">@lang('project.all')
                </a>
                @foreach($categories as $item)
                @php ( $item = $item->translate() )
                @if(blank($item->name)) @continue  @endif
                    <a href="{{ route('project.category', $item->slug) }}" class="tag_item badge {{ url()->current() == route('project.category', $item->slug) ? 'active' : ''}}">{{ $item->name }}</a>
                @endforeach
            </div>
        </div>

        {{-- <div class="style-tags">
            <div class="tag_title">
                <h4>@lang('project.tag')</h4>
            </div>
            <div class="tag-content">
                @foreach($tags as $tag)
                    <a href="{{route('project.tag', $tag->tag)}}" class="tag_item badge {{url()->current() == route('project.tag', $tag->tag) ? 'active' : '' }}">{{ $tag->tag}}</a>
                @endforeach
            </div>
        </div> --}}

        <!-- END TAGS-->

        {{-- <div class="project mt-5 mb-5">
            <div class="content container">
                <div class="row mt-5">
                    @foreach($projects as $itemOrigin)
                    @php( $item = $itemOrigin->translate() )
                    @if(blank($item->title)) @continue  @endif
                    <div class="col-sm-6 col-md-3 col-6 item pad-bton">
                        <div class="item-image">
                            <img src="{{ $itemOrigin->image ? Voyager::image($itemOrigin->thumbnail('cropped')) : $itemOrigin->defaultThumb() }}" alt="{{ $item->title }}"/>
                        </div>
                        <div class="item-text">
                            <div class="item-text-wrapper image-vector">
                                <p class="item-text-header">{{ $item->title }}</p>

                                @foreach($item->categories as $category)
                                    <p class="item-text-content">{{$category->translate()->name}}</p>
                                @endforeach

                                <span class="item-text-footer">
                                    @foreach($item->tags as $itemTag)
                                        {{ $itemTag->tag.',' }}
                                    @endforeach
                                </span>

                                <img src="{{ asset('frontend/images/icon/project-arrow.png') }}" alt="png icon project item">
                            </div>
                        </div>
                        <a class="item-link" href="{{ route('project.detail', $item->slug) }}">{{ $item->title }}</a>
                    </div>
                    @endforeach
                </div>
            </div>
        </div> --}}
        {{-- <div class="pagination justify-content-center">
            <nav data-pagination>
                {{ $projects->links('frontend.include.pagination') }}
            </nav>
        </div> --}}
    </div>
</section>

<section class="project mt-5 mb-5">
    <div class="content">
        <div class="row">

            @foreach ($projects as $itemOrigin)
            @php($item = $itemOrigin->translate())
            
            @if(blank($item->title)) @continue  @endif

            <dir class="col-md-3 col-sm-6" style="padding:0px">
                <a href="{{ route('project.detail', $item->slug) }}">
                    <div class="card proj-card">
                        <div class="dfm-inner">
                            <img class="card-img-dfm" src="{{ $itemOrigin->image ? Voyager::image($itemOrigin->thumbnail('cropped')) : $itemOrigin->defaultThumb() }}" alt="{{ $item->title }}">
                        </div>
                        <div>
                            @foreach($item->categories as $index => $category)
                                @if($index == 0)
                                    <button href="" class="btn btn-dfm_project" type="button">{{$category->translate()->name}}</button>
                                @endif
                            @endforeach
                            <span class="project-date">{{ date('m/d/Y', strtotime($item->created_at)) }}</span>
                        </div>
                        <div class="card-body">
                            <span class="card-title-dfm">{{ $item->title }}</span>
                        </div>
                    </div>
                </a>
            </dir>

            @endforeach

        </div>
    </div>
</section>
@endsection