@inject ('seoService', 'App\Services\SeoService')

@php
	$type = !empty($type) ? $type : '';
    $meta = $seoService->getMeta($model, $type);
@endphp

@section('meta-title', $meta['title'] )
@section('meta-keywords', $meta['keywords'] )
@section('meta-description', $meta['description'] )
