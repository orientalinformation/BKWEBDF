@inject('newsCategory', App\Services\NewsCategoryService)
@inject('project', App\Services\ProjectService)
@inject('service', App\Services\ServiceService)

<footer class="mt-5 container">
    <div class="footer-content mt-5">
        <div class="">
            <div class="row overflow-hidden">
                <div class="col-md-3 col-sm-12">
                    <div class="info">
                        <h5 class="ftr-title ">@lang('frontend.menu.service')</h5>
                        <nav>
                            <ul>
                                @foreach($service->getListServiceFooter() as $item)
                                <li>
                                    <a href="{{ route('service.getDetail', $item->slug) }}">
                                        {{ str_limit($item->translate()->title, 25) }}
                                    </a>
                                </li>
                                @endforeach
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="col-md-3 col-md-offset-1 col-sm-12">
                    <div class="info">
                        <h5 class="ftr-title ">@lang('frontend.menu.project')</h5>
                        <nav>
                            <ul>
                                @foreach($project->getListProjectFooter() as $item)
                                    <li>
                                        <a href="{{ route('project.detail', $item->slug) }}">
                                            {{ str_limit($item->translate()->title, 25) }}
                                        </a>
                                    </li>
                                @endforeach
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="col-md-2 col-sm-12">
                    <div class="info">
                        <h5 class="ftr-title ">@lang('frontend.menu.new')</h5>
                        <nav>
                            <ul>
                                @foreach($newsCategory->getListNewsCategoryFooter() as $item)
                                    <li>
                                        <a href="{{ route('news.category', $item->slug) }}">
                                            {{ str_limit($item->translate()->name, 18) }}
                                        </a>
                                    </li>
                                @endforeach
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="col-md-4 col-md-offset-1 col-sm-12">
                    <div class="info">
                        <h5 class="ftr-title ">@lang('frontend.menu.contact')</h5>
                        <nav style="width: 100%">
                            <ul>
                                <li>
                                    {{ $service->emailTranslate() }}
                                </li>
                                <li>
                                    {{ $service->phoneTranslate() }}
                                </li>
                                <li>
                                    {{ $service->addressTranslate() }}
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<div class="copyright text-center mt-5">
    @lang('frontend.footer.copyright')
</div>