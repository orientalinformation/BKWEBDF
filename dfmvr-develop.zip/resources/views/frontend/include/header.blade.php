@inject('homeservice', App\Services\HomeService)

{{-- <header class="{{ Request::is('/') == route('index') ? 'header dfm-banner' : 'menu-hr' }}">
    <nav id='cssmenu' class="container nav-fill w-100 {{ Request::is('/') ? 'menu' : '' }}">
        <div class="logo">
             <a href="{{ route('index') }}">
                <img class="" src="{{asset('frontend/images/icon/logoVR.png')}}" alt="logo DFM">
            </a>
        </div>
        <div id="head-mobile"></div>
        <div class="button"></div>
        
        {{ menu('user', 'frontend.user_menu') }}

    </nav>

    style="background-image: url({{ setting('site.banner') ? Voyager::image(setting('site.banner')) : asset('frontend/images/banner/banner-home.png') }})"
</header> --}}


<header class="{{ Request::is('/') == route('index') ? 'header-h_css' : 'menu-hr' }}">
   
    <div class="container" style="padding: 0px;"> 
        <nav id='cssmenu' class="nav-fill w-100 {{ Request::is('/') ? 'menu' : '' }}">
            <div class="logo">
                 <a href="{{ route('index') }}">
                    <img class="" src="{{ setting('site.logo') ? Voyager::image(setting('site.logo')) : asset('frontend/images/icon/logoVR.png')}}" alt="logo DFM">
                </a>
            </div>
            <div id="head-mobile"></div>
            <div class="button"></div>
            
            {{ menu('user', 'frontend.user_menu') }}

        </nav>
    </div>
</header>
 @if(Request::is('/') == route('index'))
    <div class="dfm_baner_old" style="background-image: url( {{ setting('site.banner') ? Voyager::image(setting('site.banner')) : asset('frontend/images/banner/banner-home.png') }} ); background-position: center center;
                                background-repeat: no-repeat;
                                background-attachment: fixed;
                                background-size: cover; height: 800px;">
        {{-- <img src="{{ setting('site.banner') ? Voyager::image(setting('site.banner')) : asset('frontend/images/banner/banner-home.png') }}" alt="dfm banner">     --}}
    </div>
@endif

