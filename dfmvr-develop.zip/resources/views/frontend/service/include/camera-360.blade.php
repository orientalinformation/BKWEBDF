@inject('pageService', 'App\Services\PageService')

<div class="service-resolve mb-5 img-reponsive_css">
    <div class="mg-top_40">
        {!! $data->translate()->title2 !!}
    </div>

    {!! $data->translate()->content !!}

	@if($pageService->getBlockBlack('360-active'))
		<div class="service-benefit mb-4">
			<div class="text-center title mt-4">
				{!! $pageService->getBlockBlack('360-active')->translate()->excerpt !!}
			</div>
			<div class="row mt-5">
				<div class="col-lg-6 mb-3">
					<img src="{{ $pageService->getBlockBlack('360-active')->image ? Voyager::image($pageService->getBlockBlack('360-active')->image) : asset('frontend/images/banner/banner-service2.png')}}" alt="{{$pageService->getBlockBlack('360-active')->title }}" width="100%" height="100%">
				</div>

				<div class="col-lg-6 css_360_icon_li">
					{!! $pageService->getBlockBlack('360-active')->translate()->body !!}
				</div>

			</div>
		</div>
	@endif

	<div class="">
		{!! $pageService->getBlockBlack('360-block')->translate()->body !!}
    </div>
</div>
