@inject('pageService', 'App\Services\PageService')

<div class="container img-reponsive_css">
    <div class="mb-5">
        <div class="mg-top_40">
            {!! $data->translate()->title2 !!}
        </div>
        
        <div class="">

            @if($data->content)
                {!! $data->translate()->content !!}                
            @endif

            @if($pageService->getBlockBlack('technology-AR'))
                <div class="row ">
                    <div class="icon-hr col-lg-12 mg-top_40"></div>
                    <div class="col-lg-6 mg-top_20">
                        {!! $pageService->getBlockBlack('technology-AR')->translate()->body !!}
                    </div>
                    <div class="col-lg-6 text-center">
                        <img src="{{ $pageService->getBlockBlack('technology-AR')->image ? Voyager::image($pageService->getBlockBlack('technology-AR')->image) : asset('frontend/images/banner/banner-service5.png')}}" alt="{{ $pageService->getBlockBlack('technology-AR')->title}}" width="90%" height="90%">
                    </div>
                </div>
            @endif

        </div>
    </div>
</div>
