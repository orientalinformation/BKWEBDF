<div class="mb-5 img-reponsive_css">
    <div class="mg-top_40">
        {!! $data->translate()->title2 !!}
    </div>
    <div id="carousel-bulid-model" class="carousel slide carousel-multi-item v-2" data-ride="carousel" data-interval="5000">
        <div class="row m-0">
            <div class="controls-top col-12 d-flex flex-row-reverse">
                <a class="btn-floating mr-2" href="#carousel-bulid-model" data-slide="next">
                    <i class="fa fa-angle-right" aria-hidden="true"></i>
                </a>
                <a class="btn-floating ml-2" href="#carousel-bulid-model" data-slide="prev">
                    <i class="fa fa-angle-left" aria-hidden="true"></i>
                </a>
            </div>
        </div>
        <div class="row carousel-inner v-2 m-0" role="listbox">
            @if(!empty($models = $data->models))
                @php($i = 0)
                @foreach($models as $item)
                    @php($item = $item->translate(session('locale'), config('voyager.multilingual.default')))
                    <div class="carousel-item {{ $i == 0 ? 'active' : '' }}">
                        <div class="col-lg-2dot4 col-sm-4 col-12 col-md-3">
                            <div class="card mb-2 p-3 carousel-item-height">
                                <div class="text-center">
                                    <p class="card-title font-weight-bold mb-0">{{ $item->title }}</p>
                                    <span class="card-title-more">{{ $item->description }}</span>
                                </div>
                                <span class="text-center title-more text-color-prink">@lang('frontend.button.btn_contact')</span>
                                <div class="btn-build-dfm">
                                    <a href='{{ $item->link }}' class="btn btn-seen">@lang('frontend.button.btn_learnmore')</a>
                                </div>
                            </div>
                            <div class="mt-4 title-more">
                                <ul class="item-des fa-ul">

                                    @if($item->list_features)
                                        @foreach(explode("\n", $item->list_features) as $value)
                                            <li><span class="fa-li"><i class="fa fa-check"></i></span>{{ $value }}</li>
                                        @endforeach
                                    @endif
                                    
                                </ul>
                            </div>
                        </div>
                    </div>
                    @php($i++)
                @endforeach
            @endif
        </div>
    </div>
        
    <div class="responsive mt-5 mb-5" >
        {!! $data->translate()->content !!}
    </div>
</div>
