<div class="container img-reponsive_css">
    <div class="mb-5">

    	<div class="mg-top_40">
            {!! $data->translate()->title2 !!}
        </div>
		
		<div class="" > 
	        {!! $data->translate()->content !!}
		</div>
    </div>
</div>
