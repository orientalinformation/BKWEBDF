@inject('homeservice', App\Services\HomeService)

@extends('layouts.frontend')

@include('frontend.include.meta_seo', ['model' => $data])

@section('content')

<!-- Sub menu -->
<section class="sub-menu">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light menu">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    @if(!empty($submenu))
                    @foreach($submenu as $item)
                    @php($item = $item->translate(session('locale'), config('voyager.multilingual.default')))
                    <li class="nav-item item-menu  {{ $homeservice->activeMenu("services/$item->slug") }}">
                        <a class="nav-link" href='{{url("services/$item->slug")}}'>{{$item->title}} </a>
                    </li>
                    @endforeach
                    @endif
                </ul>
            </div>
        </nav>
    </div>
</section>
<!-- end Sub menu -->

<!-- Content service -->
@if(!empty($data))
    <section class="service-content">
        <div class="container">
            @switch($data->slug)
                @case('chup-hinh-360')
                @case('capture-360')
                    @include('frontend.service.include.camera-360', ['data' => $data])
                    @break
                @case('ung-dung-cong-nghe-ar')
                @case('application-ar')
                    @include('frontend.service.include.technology-ar')
                    @break
                @case('xay-dung-hinh-mau')
                @case('prototyping')
                    @include('frontend.service.include.build-model')
                    @break
                @case('linh-kien')
                @case('components')
                    @include('frontend.service.include.components')
                    @break
                @default
                    {!! $data->content !!}
            @endswitch
        </div>
    </section>
@endif
<!-- end Content service -->
<div class="container">
    <div class="cotnact-benefit">
    </div>
    {{ Widget::BlockHomeContact() }}
</div>

@endsection