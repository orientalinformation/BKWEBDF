@extends('layouts.frontend')

@include('frontend.include.meta_seo', ['model' => null, 'type' => 'contact'])

@section('content')
   
    {{ Widget::BlockHomeContact() }}

@endsection