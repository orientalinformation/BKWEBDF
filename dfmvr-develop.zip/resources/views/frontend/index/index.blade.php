@extends('layouts.frontend')

@include('frontend.include.meta_seo', ['model' => null])

@section('content')
    
    {{ Widget::BlockHomeAbout() }}

    {{ Widget::BlockHomeService() }}

    {{ Widget::BlockHomeProject() }}
    
    {{ Widget::BlockHomeNews() }}    

    {{ Widget::BlockHomeContact() }}

@endsection