@inject ('imageService', 'App\Services\ImageService')

@include('frontend.include.meta_seo', ['model' => $page])

@extends('layouts.frontend')

@section('content')

<section class="introduce mt-5 mb-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <h2>{!! $page->translate()->excerpt !!}</h2>
                <p class="content">
                    {!! $page->translate()->body !!}
                </p> 
            </div>
            <div class="col-lg-6 text-center">
                <img src="{{asset('frontend/images/banner/banner-introduce1.png')}}" alt="intro" width="100%" height="100%">
            </div>
        </div>
    </div>
</section>

<section class="introduce mt-5 mb-5">
    <div class="container">
        @lang('frontend.title.sub-title-introduce2')
        <div class="row">
            @if(!empty($partner->count()))
                @foreach($partner as $item)
                @php( $item = $item->translate() )
                    <div class="col-md-4 col-12">
                        <div class="introduce-item">
                            <a href="{{ $item->link }}"  target="_blank">
                                <div class="mt-4 mb-4 ml-3 mr-3">
                                    <div class="introduct-logo mb-5">
                                        <img src="{{ $imageService->thumb($item) }}" alt="{{ $item->name }}"/>
                                    </div>
                                    <div class="introduct-content">
                                        <p class="hover">{{ $item->name }}</p>
                                        <span style="color: #320773">{{ $item->description }}</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                @endforeach
            @endif
        </div>
    </div>
</section>

@endsection