@php
    $path = request()->segment(1);
@endphp

<ul class="menu-wrapper">
   @foreach($items as $index=>$menu_item)
        @if($index == 0) 
            <li class="item-menu {{ request::is('/')  ? 'active' : '' }}">
                <a href="{{ $menu_item->link() }}">{{ $menu_item->getTranslatedAttribute('title') }}</a>
            </li>
        @else
            <li class="item-menu {{ strpos($menu_item->link(), $path) !== false  ? 'active' : '' }}">
                <a href="{{ $menu_item->link() }}">{{ $menu_item->getTranslatedAttribute('title') }}</a>
            </li>
        @endif
    @endforeach
    @php($locales = config('voyager.multilingual.locales'))
    <li class="item-menu bg_css_lang">
        <a class="lag" href='javascript:void(0)'>{{ app()->getLocale() }}</a>
        <ul>
            @foreach($locales as $locale)
                @if($locale !== app()->getLocale())
                    <li>
                        <a href='{{ route('locale.change', $locale) }}'>{{ $locale }}</a>
                    </li>
                @endif
            @endforeach
        </ul>
    </li>
</ul>
