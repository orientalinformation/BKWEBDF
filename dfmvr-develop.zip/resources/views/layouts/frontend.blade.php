<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
    <title>@yield('meta-title')</title>
    <meta name="description" content="@yield('meta-description')">
    <meta name="keywords" content="@yield('meta-keywords')">
    @if (app()->environment() != 'prod')
        <meta name="robots" content="noindex, nofollow">
    @endif

	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
	<link href="https://fonts.googleapis.com/css?family=Varela+Round&display=swap" rel="stylesheet"> 
	{!! Html::style('/frontend/css/bootstrap.min.css') !!}
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
	{!! Html::style('/frontend/css/menu.css') !!}
	{!! Html::style('/frontend/css/style.css') !!}
	{!! Html::style('/frontend/css/custom.css') !!}
	{!! Html::style('/frontend/css/v2.css') !!}
	@stack('stylesheets')

</head>

<body style="font-family: 'Varela Round', sans-serif; font-size: 16px; font-weight: 500">

	<div class="container-fluid">

		@include('frontend.include.header')
		
		@yield('content')

		@include('frontend.include.footer')
	
	</div>

	{!! Html::script('frontend/js/jquery.min.js') !!}
	{!! Html::script('frontend/js/bootstrap.min.js') !!}
	{!! Html::script('frontend/js/menu.js') !!}
	{!! Html::script('frontend/js/myScript.js') !!}
	@stack('scripts')
	
</body>

</html>