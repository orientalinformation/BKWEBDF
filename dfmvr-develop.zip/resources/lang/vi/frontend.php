<?php
return [
    'title' => [
        'about'              => 'Giới Thiệu', 
        'sub_title_about'    => '<p>Xin chào! Chúng tôi là
                                    <span>DFM-VR</span>
                                </p>
                                <p>Chuyên cung cấp dịch vụ liên quan dến
                                    <span>công nghệ thực tế ảo</span>
                                </p>',
        'service'            => 'Dịch vụ',
        'sub_title_service'  => '<p> Công nghệ linh hoạt
                                <span>giàu sức tưởng tượng</span>
                                </p>',
        'service_des'        => 'Truyền cảm hứng sáng tạo đậm nét bao trùm các giác quan',
        'btn_more'           => 'Xem thêm',
        'project'            => "Dự án tiêu biểu",
        'news'               => 'Tin tức',
        'contact'            => 'Liên hệ',
        'sub_title_contact1' => 'Bạn cần đặt câu hỏi? Bạn cần tư vấn kỹ thuật?',
        'sub_title_contact2' => 'Hãy liên hệ với chúng tôi qua email',
        'or_telephone'       => 'hoặc số điện thoại',
        'sub_title_project'  => '<h2 class="font-weight-bold">Dự án
                                <span class="text-color-prink">DFM-VR</span></h2>
                                <h4 class="title-sub">Công nghệ tương tác chuyên biệt hóa</h4>',
        'addresses' => 'DFM-Engineering, Tòa nhà Helios, Công viện phần mềm Quang Trung, Quận 12, TP HCM',
        'sub-title-introduce1' => '<h2 class="title"> Đây là tôi
                                    <span>DFM-VR</span>
                                </h2>',
        'sub-title-introduce2' => '<h2 class="title">Những điểm sáng khác của
                                    <span>DFM Engineering</span>
                                </h2>',
        'sub-title-service-bulid-model' =>  '<h2 class="font-weight-bold"> Lĩnh vực rộng mở
                                            <span class="text-color-prink">Nâng cấp hiển thị</span>
                                            </h2>
                                            <h4 class="title-sub">Nâng cao trải nghiệm xem thông thường, vượt qua những rào cản tương tác.</h4>',
    ],
    'button' =>[
        'btn_more'           => 'Xem thêm',
        'btn_learnmore' =>'Trải nghiệm',
        'btn_contact' => 'Liên hệ nhận báo giá'
    ],
    'placeholder' => [
        'contact_name' => 'Họ và tên (*)',
        'contact_email' => 'Email (*)',
        'contact_tel' => 'Số điện thoại (*)',
        'contact_field' => 'Lĩnh vực quan tâm (*)',
        'contact_content' => 'Mô tả chính những thông tin bạn cần (*)',
        'contact_confirm' => 'Xác nhận'
    ],
    'menu' => [
        'home' => 'Trang chủ',
        'introduce' => 'Giới thiệu',
        'service' => 'Dịch vụ',
        'project' => 'Dự án',
        'new' => 'Tin tức',
        'contact' => 'Liên hệ'
    ],
    'messages' => [
        'success' => 'Bạn đã gởi thành công!',
    ],
    'footer' => [
        'email'     => 'Email: ',
        'tel'       => 'Điện Thoại: ',
        'address'   => 'Địa Chỉ: ',
        'copyright' => 'Copyright © 2019. DFM-Engineering. All rights reserved.'
    ],
    'seo' => [
        "contact" => 'Liên hệ',
        "news"    => 'Trang tin tức',
        "service" => 'Trang dịch vụ',
        "project" => 'Trang sản phẩm',
    ]
];