<?php

return [
    'messages' =>[
        'erro' => 'fail',
        'success' => 'success',
    ],

    'select' => [
    	'ar' => 'AR',
    	'vr' => 'VR',
    	'other' => 'Autre',
    ],
    'media' => [
    	'title' => 'Médias sociaux'
    ],
];
