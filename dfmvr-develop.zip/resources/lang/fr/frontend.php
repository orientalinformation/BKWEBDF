<?php

return [
    'title' => [
        'about'              => 'À Propos de DFM-VR',
        'sub_title_about'    => '<p>Bonjour! Nous sommes
                                    <span>DFM-VR</span>
                                </p>
                                <p>Spécialisé dans la fourniture de services liés à la technologie de
                                    <span>réalité virtuell</span>
                                </p>',
        'service'            => 'Nos services',
        'sub_title_service'  => '<p>La technologie au service 
                                <span>de vos créativités</span>
                                </p>',
        'service_des'        => 'Découvrez une experience premium',
        'project'            => "Projets",
        'news'               => 'Actualités',
        'contact'            => 'Contact',
        'sub_title_contact1' => 'Des questions? Besoin de conseils techniques?',
        'sub_title_contact2' => 'Contactez-nous et nous serons heureux de vous répondre',
        'or_telephone'       => 'ou par telephone au',   
        'sub_title_project'  => '<h2 class="font-weight-bold">Projet de
                                <span class="text-color-prink">DFM-VR</span></h2>
                                <h4 class="title-sub">Une technologie à la fonctionalité désirée</h4>',
        'addresses' => 'DFM-Engineering, Tòa nhà Helios, Công viện phần mềm Quang Trung, Quận 12, TP HCM',
        'sub-title-introduce1' => '<h2 class="title"> Nous sommes 
                                    <span>DFM-VR</span>
                                </h2>',
        'sub-title-introduce2' => '<h2 class="title">Voir plus les projets de
                                    <span>DFM Engineering</span>
                                </h2>',
        'sub-title-service-bulid-model' =>  '<h2 class="font-weight-bold"> L’intégralité scénarisables et
                                            <span class="text-color-prink">personalisable</span>
                                            </h2>
                                            <h4 class="title-sub">Une expérience hors de sensation.</h4>',
    ],
    'button' =>[
        'btn_more'           => 'En savoir plus',
        'btn_learnmore' =>'En savoir plus   ',
        'btn_contact' => 'Contactez-nous pour le devis'

    ],
    'placeholder' => [
        'contact_name' => 'Nom et prénom (*)',
        'contact_email' => 'Email (*)',
        'contact_tel' => 'Tel (*)',
        'contact_field' => 'Domain qui vous intéressent (*)',
        'contact_content' => 'Décrivez-vous en quelques mots votre besoin (*)',
        'contact_confirm' => 'Confirmation'
    ],
    'menu' => [
        'home' => 'Accueil',
        'introduce' => 'À propos de',
        'service' => 'Nos services',
        'project' => 'Projets',
        'new' => 'Actualités',
        'contact' => 'Contact'
    ],
    'messages' => [
        'success' => 'Vous avez envoyé avec succès!',
    ],
    'footer' => [
        'email'     => 'Email: ',
        'tel'       => 'Tel: ',
        'address'   => 'Adresse: ',
        'copyright' => 'Copyright © 2019. DFM-Engineering. Tous les droits sont réservés.'
    ],
    'seo' => [
        "contact" => 'Contact',
        "news"    => 'Actualités',
        "service" => 'Nos services',
        "project" => 'Projects',
    ]
];
