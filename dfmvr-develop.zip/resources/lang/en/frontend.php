<?php
return [
    'title' => [
        'about'              => 'Introduce',
        'sub_title_about'    => '<p>Hello! We are
                                <span>DFM-VR team</span>
                                 </p>
                                 <p>We are experts in the 
                                <span>virtual reality solutions</span>
                                </p>',
        'service'            => 'Service',
        'sub_title_service'  => '<p> Flexibility and 
                                <span>Imagination</span>
                                </p>',
        'service_des'        => 'Inspirational creativity embraces the senses',
        'project'            => "Projects",
        'news'               => 'News',
        'contact'            => 'Contact',
        'sub_title_contact1' => 'Questions? Need technical advice?',
        'sub_title_contact2' => 'Contact us and we will be happy to answer you',
        'or_telephone'       => 'or phone',
        'sub_title_project'  => '<h2 class="font-weight-bold ">DFM -VR’s
                                <span class="font-weight-bold">Project</span></h2>
                                <h4 class="title-sub">A specific interaction</h4>',
        'addresses' => 'DFM-Engineering, Heliosbuilding, Quang Trung Software City, district 12, HCMC',
        'sub-title-introduce1' => '<h2 class="title"> We are
                                    <span>DFM-VR</span>
                                </h2>',
        'sub-title-introduce2' => '<h2 class="title">See more projects from
                                    <span>DFM Engineering</span>
                                </h2>',
        'sub-title-service-bulid-model' =>  '<h2 class="font-weight-bold">Scenario and 
                                <span class="text-color-prink">customizable integration</span>
                                </h2>
                                <h4 class="title-sub">An experience out of sensation.</h4>'
    ],
    'button' => [
        'btn_more'           => 'Learn more',
        'btn_learnmore' => 'Learn more',
        'btn_contact' => 'Contact us for the quotation'
    ],
    'placeholder' => [
        'contact_name' => 'Full name (*)',
        'contact_email' => 'Email (*)',
        'contact_tel' => 'Tel (*)',
        'contact_field' => 'Field in which you interested (*)',
        'contact_content' => 'Describe yourself in a few words your need (*)',
        'contact_confirm' => 'Confirmation'
    ],
    'menu' => [
        'home' => 'Home',
        'introduce' => 'About',
        'service' => 'Services',
        'project' => 'Projects',
        'new' => 'News',
        'contact' => 'Contact'
    ],
    'messages' => [
        'success' => 'You have successfully sent!',
    ],
    'footer' => [
        'email'     => 'Email: ',
        'tel'       => 'Tel: ',
        'address'   => 'Address: ',
        'copyright' => 'Copyright © 2019. DFM-Engineering. All rights reserved.'
    ],
    'seo' => [
        "contact" => 'Contact',
        "news"    => 'News',
        "service" => 'Services',
        "project" => 'Projects',
    ]
];
