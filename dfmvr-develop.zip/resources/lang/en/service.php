<?php

return [
    'additional_fields'=> 'Additional Fields',
    'category'         => 'Service Category',
    'content'          => 'Service Content',
    'details'          => 'Service Details',
    'excerpt'          => 'Excerpt <small>Small description of this service</small>',
    'image'            => 'Service Image',
    'new'              => 'Create New Service',
    'slug'             => 'URL slug',
    'status'           => 'Service Status',
    'title'            => 'Service Title',
    'title_sub'        => 'The title for your service',
    'update'           => 'Update Service',
    'title2'           => 'Custom Title',
];
