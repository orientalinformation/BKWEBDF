<?php

return [
    'project'                 => 'Project|Projects',
    'project_link_text'       => 'View all projects',
    'project_text'            => 'You have :count :string in your database. Click on button below to view all projects.',
    'news'                    => 'News|News',
    'news_link_text'          => 'View all news',
    'news_text'               => 'You have :count :string in your database. Click on button below to view all news.',
    'contact'                 => 'Contact|Contacts',
    'contact_link_text'       => 'View all contacts',
    'contact_text'            => 'You have :count :string in your database. Click on button below to view all contacts.',
    'service_model'           => 'Service Model|Service Models',
    'service_model_link_text' => 'View all service models',
    'service_model_text'      => 'You have :count :string in your database. Click on button below to view all service models.',
];
