<?php

return [
    'meta_description' => 'Meta Description',
    'meta_keywords'    => 'Meta Keywords',
    'seo_content'      => 'SEO Content',
    'seo_title'        => 'SEO Title',
];
