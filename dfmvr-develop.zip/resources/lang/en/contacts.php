<?php

return [
    'messages' =>[
        'erro' => 'fail',
        'success' => 'success',
    ],

    'select' => [
    	'ar' => 'AR',
    	'vr' => 'VR',
    	'other' => 'Other',
    ],
    'media' => [
    	'title' => 'Social media'
    ],
];
