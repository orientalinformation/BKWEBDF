<?php

return [
    'additional_fields'=> 'Additional Fields',
    'category'         => 'Page Category',
    'content'          => 'Page Content',
    'details'          => 'Page Details',
    'excerpt'          => 'Excerpt <small>Small description of this Page</small>',
    'image'            => 'Page Image',
    'new'              => 'Create New Page',
    'slug'             => 'URL slug',
    'status'           => 'Page Status',
    'title'            => 'Page Title',
    'title_sub'        => 'The title for your Page',
    'update'           => 'Update Page',
];
