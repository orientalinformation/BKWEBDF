<?php

return [
    'secret' => env('NOCAPTCHA_SECRET', '6LdkAqcUAAAAAFK3kG8oViMUPpC6jepx0sJaLHc3'),
    'sitekey' => env('NOCAPTCHA_SITEKEY', '6LdkAqcUAAAAAD1PEkAiJp07vSD-9usaJqLTwI0-'),
    'options' => [
        'timeout' => 30,
    ],
];