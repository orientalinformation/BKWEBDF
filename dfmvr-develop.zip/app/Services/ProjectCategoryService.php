<?php

namespace App\Services;

use App\Repositories\Contracts\ProjectCategoryRepository;
use App\Services\AbstractService;

class ProjectCategoryService extends AbstractService
{
    protected $category;

    public function __construct(ProjectCategoryRepository $category)
    {
        $this->category = $category;
    }

    public function getListProjectCategoryFooter() {
    	return $this->category->all();
    }

}