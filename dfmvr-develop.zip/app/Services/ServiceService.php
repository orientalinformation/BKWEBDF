<?php

namespace App\Services;

use App\Repositories\Contracts\ServiceRepository;
use App\Services\AbstractService;

class ServiceService extends AbstractService
{
    protected $repository;

    public function __construct(ServiceRepository $repository)
    {
        $this->repository = $repository;
    }

    public function getListServiceFooter() {
    	return $this->repository->getLimit(5);
    }

    public function phoneTranslate() {
        $tel = "";
        if( app()->getLocale() == "fr") {
            $tel = setting('site.tel_fr');
        }elseif( app()->getLocale() == "en") {
            $tel = setting('site.tel_en');
        }else {
            $tel = setting('site.tel');
        }
        return $tel;
    }

    public function addressTranslate() {
        $address = "";
        if( app()->getLocale() == "fr") {
            $address = setting('site.address_fr');
        }elseif( app()->getLocale() == "en") {
            $address = setting('site.address_en');
        }else {
            $address = setting('site.address');
        }
        return $address;
    }
    public function emailTranslate() {
        $address = "";
        if( app()->getLocale() == "fr") {
            $address = setting('site.email_fr');
        }elseif( app()->getLocale() == "en") {
            $address = setting('site.email_en');
        }else {
            $address = setting('site.email');
        }
        return $address;
    }
}