<?php

namespace App\Services;

use App\Repositories\Contracts\ProjectRepository;
use App\Services\AbstractService;

class ProjectService extends AbstractService
{
    protected $repository;

    public function __construct(ProjectRepository $repository)
    {
        $this->repository = $repository;
    }

    public function getListProjectFooter() {
    	return $this->repository->getLimit(5);
    }

}