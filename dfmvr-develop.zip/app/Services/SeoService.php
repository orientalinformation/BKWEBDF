<?php

namespace App\Services;

class SeoService
{
    public function getMeta($model, $type = '')
    {
        $meta = [];

        // default
        $meta['title'] = 'DFMVR';
        $meta['keywords'] = 'DFMVR';
        $meta['description'] = 'DFMVR';

        if (!empty($type)) {
            return $this->getCustom($meta, $type);
        }

        if (empty($model)) {
            //$model = $this->getSeoStaticLink();
        }

        if (!empty($model->seo->seo_title)) {
            $meta['title'] = $model->seo->translate()->seo_title;
        }
        else {
            if (!empty($model->title)) {
                $meta['title'] = $model->translate()->title;
            }
            // for category
            elseif (!empty($model->name)) {
                $meta['title'] = $model->translate()->name;
            }
        }

        if (!empty($model->seo->meta_keywords)) {
            $meta['keywords'] = $model->seo->translate()->meta_keywords;
        }

        if (!empty($model->seo->meta_description)) {
            $meta['description'] = $model->seo->translate()->meta_description;
        }
        else {
            if (!empty($model->title)) {
                $meta['description'] = $model->translate()->title;
            }
            // for category
            elseif (!empty($model->name)) {
                $meta['description'] = $model->translate()->name;
            }
        }

        return $meta;
    }

    public function getCustom($meta, $type = '')
    {
        if (empty($type)) {
            return;
        }

        switch ($type) {
            case 'home':
                    $meta['title'] = __('frontend.seo.home');
                    $meta['keywords'] = __('frontend.seo.home');
                    $meta['description'] = __('frontend.seo.home');
                break;
            case 'project':
                    $meta['title'] = __('frontend.seo.project');
                    $meta['keywords'] = __('frontend.seo.project');
                    $meta['description'] = __('frontend.seo.project');
                break;
            case 'news':
                    $meta['title'] = __('frontend.seo.news');
                    $meta['keywords'] = __('frontend.seo.news');
                    $meta['description'] = __('frontend.seo.news');
                break;
            case 'contact':
                    $meta['title'] = __('frontend.seo.contact');
                    $meta['keywords'] = __('frontend.seo.contact');
                    $meta['description'] = __('frontend.seo.contact');
                break;

            default:
                
                break;
        }

        return $meta;
        
         

    }
}