<?php

namespace App\Services;

use App\Repositories\Contracts\NewsRepository;
use App\Services\AbstractService;

class NewsService extends AbstractService
{
    protected $repository;

    public function __construct(NewsRepository $repository)
    {
        $this->repository = $repository;
    }

    public function getListNewsFooter() {
    	return $this->repository->getLimit(5);
    }

}