<?php

namespace App\Services;

use App\Services\AbstractService;
use TCG\Voyager\Facades\Voyager;

class ImageService extends AbstractService
{
    public function thumb($model, $type = '', $field = 'image')
    {
        if (get_class($model) == 'TCG\Voyager\Translator') {
            $model = $model->getModel();
        }
        if (!empty($type)) {
            $image = $model->thumbnail($type, $field);
        }
        else {
            $image = $model->{$field};  
        }

        return Voyager::image($image, $model->defaultThumb());
    }

}