<?php

namespace App\Services;

use App\Repositories\Contracts\NewsCategoryRepository;
use App\Services\AbstractService;

class NewsCategoryService extends AbstractService
{
    protected $category;

    public function __construct(NewsCategoryRepository $category)
    {
        $this->category = $category;
    }

    public function getListNewsCategoryFooter() {
    	return $this->category->all();
    }

}