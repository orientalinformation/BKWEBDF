<?php

namespace App\Services;

abstract class AbstractService
{
    //protected $repository;

/*    public function all()
    {
        return $this->repository->all();
    }

    public function count()
    {
        return $this->repository->count();
    }*/
}