<?php

namespace App\Services;

use App\Repositories\Contracts\PageRepository;
use App\Services\AbstractService;

class PageService extends AbstractService
{
    protected $repository;

    public function __construct(PageRepository $repository)
    {
        $this->repository = $repository;
    }

    public function getBlockBlack($slug) {
    	return $this->repository->getDetail($slug);
    }

}