<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Trails\Seoable;
use App\Http\Controllers\Voyager\VoyagerBaseController;

class PageController extends VoyagerBaseController
{
    use Seoable;
}
