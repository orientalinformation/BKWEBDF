<?php

namespace App\Http\Controllers\Admin;

class PostController extends \App\Http\Controllers\Voyager\VoyagerBaseController
{

}