<?php namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Repositories\Contracts\ServiceRepository;
use App\Repositories\Contracts\ServiceModelRepository;

class ServiceController extends Controller
{
    public function __construct(ServiceRepository $repository, ServiceModelRepository $serviceModel)
    {
        $this->repository = $repository;
        $this->serviceModel = $serviceModel;
    }

    public function index()
    {
        return redirect()->route('service.getDetail', Service::firstOrFail()->slug);

        $submenu = $this->repository->GetAll();
        $data = array();
        if (count($submenu) >0) {
            $data = $this->repository->GetDetail($submenu->first()->slug);
        }

        return view('frontend.service.index', compact('submenu', 'data'));
    }

    public function getDetail($slug)
    {
        $submenu = $this->repository->GetAll();
        $data = $this->repository->GetDetail($slug);
        $data = Service::whereSlug($slug)->first();
        $service_Model = $this->serviceModel->GetDetail($data->first()->id);

        return view('frontend.service.index', compact('submenu', 'data', 'service_Model'));
    }
}
