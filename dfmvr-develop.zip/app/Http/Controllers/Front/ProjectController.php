<?php namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\News;
use App\Models\Tag;
use App\Repositories\Contracts\ProjectRepository;
use App\Repositories\Contracts\ProjectCategoryRepository;
use App\Repositories\Contracts\TagRepository;

class ProjectController extends Controller
{
	 public function __construct(ProjectRepository $repository, ProjectCategoryRepository $category, TagRepository $tag)
    {
        $this->repository = $repository;
        $this->category   = $category;
        $this->tag        = $tag;
    }


    public function index()
    {	
        $categories = $this->category->all();
    	$projects = $this->repository->getPaginate(12);
        $tags = $this->tag->all();

        return view('frontend.project.index', compact('projects', 'categories', 'tags'));
    }

    public function detail ($slug) 
    {
    	$project = $this->repository->getDetail($slug);

    	if(empty($project)){
    		abort(404);
    	}

         $categories = $this->category->all();
    	return view('frontend.project.detail', compact('project', 'categories'));
    }

    public function category($slug) {

        $tags       = $this->tag->all();
        $categories = $this->category->all();
        $projects   = $this->category->getProjectWithCategory($slug, 8);

        return view('frontend.project.index', compact('categories', 'projects', 'tags'));
    }

    public function getprojectWithTag ($tag)
    {
        $tags       = $this->tag->all();
        $categories = $this->category->all();
        $projects   = $this->tag->getProjectWithTag($tag, 8);

        return view('frontend.project.index', compact('categories', 'projects', 'tags'));
    }
}