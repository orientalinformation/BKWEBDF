<?php namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Repositories\Contracts\ContactRepository;
use Illuminate\Http\Request;
use App\Models\Contact;
use Illuminate\Support\Facades\Validator;

class ContactController extends Controller
{
    public function __construct(ContactRepository $repository)
    {
        $this->repository = $repository;
    }

    public function post (Request $request)
    {
        $input = $request->all();

        $data = [
            'name'     => $input['name'],
            'email'    => $input['email'],
            'phone'    => $input['phone'],
            'field'    => $input['field'],
            'message'  => $input['message'],
            'status'   => Contact::STATUS_ACTIVE,
            'captcha2' => $input['g-recaptcha-response']
        ];

        $validator = Validator::make($data, [
            // 'name'     => 'required',
            // 'email'    => 'required|email',
            // 'phone'    => 'required',
            // 'field'    => 'required',
            // 'message'  => 'required',
            'captcha2' => 'required'
        ]);
        if ($validator->fails()) {
            return ['error' => 1, 'message' => $validator->errors()->first() ];
        }

        $this->repository->saveContact($data);

        return ['error' => 0, 'message' => __('frontend.messages.success')];
    }

    public function get()
    {
        return view('frontend.contact.index');
    }

}
