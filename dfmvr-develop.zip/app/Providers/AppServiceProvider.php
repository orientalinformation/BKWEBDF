<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);

        $default_local = session('locale');
        if (empty($default_local)) {
            $ip = \Request::ip();
            $position = \Location::get($ip);
            if (!empty($position) && $position->countryCode == 'VN') {
                session(['locale' => 'vi']);
                $default_local = 'vi';
            }elseif (!empty($position) && $position->countryCode == 'FR') {
                session(['locale' => 'fr']);
                $default_local = 'fr';
            }
            else {
                session(['locale' => 'en']);
                $default_local = 'en';
            }
        }else{
            config(['translatable.locale' => $default_local]);
            config(['app.locale' => $default_local]);
            config(['voyager.multilingual.default' => $default_local]);
        }

        // $default_local = session('locale');
        // if (!empty($default_local)) {
        //     config(['translatable.locale' => $default_local]);
        //     config(['app.locale' => $default_local]);
        //     config(['voyager.multilingual.default' => $default_local]);
        // }
    }
}
