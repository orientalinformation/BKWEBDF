<?php

namespace App\Widgets;

use App\Models\ServiceModel;
use TCG\Voyager\Widgets\BaseDimmer;

class ServiceModelDimmer extends BaseDimmer
{
    /**
     * The configuration array.
     *
     * @var array
     */
    protected $config = [];

    /**
     * Treat this method as a controller action.
     * Return view() or other content to display.
     */
    public function run()
    {
        $count = ServiceModel::count();
        $string = trans_choice('dimmer.service_model', $count);

        return view('voyager::dimmer', array_merge($this->config, [
            'icon'   => 'voyager-pie-chart',
            'title'  => "{$count} {$string}",
            'text'   => __('dimmer.service_model_text', ['count' => $count, 'string' => strtolower($string)]),
            'button' => [
                'text' => __('dimmer.service_model_link_text'),
                'link' => route('voyager.service_models.index'),
            ],
            'image' => voyager_asset('images/widget-backgrounds/02.jpg'),
        ]));
    }

    /**
     * Determine if the widget should be displayed.
     *
     * @return bool
     */
    public function shouldBeDisplayed()
    {
        return app('VoyagerAuth')->user()->can('browse', new ServiceModel());
    }
}
