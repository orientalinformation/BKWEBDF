<?php

namespace App\Widgets;

use App\Models\Page;

class PageDimmer extends \TCG\Voyager\Widgets\PageDimmer
{
    /**
     * Determine if the widget should be displayed.
     *
     * @return bool
     */
    public function shouldBeDisplayed()
    {
        return app('VoyagerAuth')->user()->can('browse', new Page());
    }
}
