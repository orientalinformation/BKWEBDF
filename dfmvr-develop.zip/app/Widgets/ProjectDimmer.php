<?php

namespace App\Widgets;

use App\Models\Project;
use TCG\Voyager\Widgets\BaseDimmer;

class ProjectDimmer extends BaseDimmer
{
    /**
     * The configuration array.
     *
     * @var array
     */
    protected $config = [];

    /**
     * Treat this method as a controller action.
     * Return view() or other content to display.
     */
    public function run()
    {
        $count = Project::count();
        $string = trans_choice('dimmer.project', $count);

        return view('voyager::dimmer', array_merge($this->config, [
            'icon'   => 'voyager-documentation',
            'title'  => "{$count} {$string}",
            'text'   => __('dimmer.project_text', ['count' => $count, 'string' => strtolower($string)]),
            'button' => [
                'text' => __('dimmer.project_link_text'),
                'link' => route('voyager.projects.index'),
            ],
            'image' => voyager_asset('images/widget-backgrounds/02.jpg'),
        ]));
    }

    /**
     * Determine if the widget should be displayed.
     *
     * @return bool
     */
    public function shouldBeDisplayed()
    {
        return app('VoyagerAuth')->user()->can('browse', new Project());
    }
}
