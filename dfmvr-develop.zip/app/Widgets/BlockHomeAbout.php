<?php

namespace App\Widgets;

use Arrilot\Widgets\AbstractWidget;
use App\Repositories\Contracts\PageRepository;

class BlockHomeAbout extends AbstractWidget
{
    /**
     * The configuration array.
     *
     * @var array
     */
    protected $config = [];

    /**
     * Treat this method as a controller action.
     * Return view() or other content to display.
     */
    public function run()
    {
        $page =  app(PageRepository::class);
        $data = $page->getDetail('introduce');
        return view('widgets.block_home_about', [
            'config' => $this->config,
            'data' => $data,
        ]);
    }
}
