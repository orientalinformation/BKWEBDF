<?php

namespace App\Repositories\Eloquent;

use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Repository\Criteria\RequestCriteria;
use App\Repositories\Contracts\ServiceModelRepository;
use App\Models\ServiceModel;

/**
 * Class ServiceRepositoryEloquent.
 *
 * @package namespace App\Repositories\Eloquent;
 */
class ServiceModelRepositoryEloquent extends BaseRepository implements ServiceModelRepository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return ServiceModel::class;
    }

    public function GetDetail($service_id)
    {
        $data = ServiceModel::where('service_id', $service_id)->get();
        return $data;
    }
    /**
     * Boot up the repository, pushing criteria
     */
    public function boot()
    {
        $this->pushCriteria(app(RequestCriteria::class));
    }
}
