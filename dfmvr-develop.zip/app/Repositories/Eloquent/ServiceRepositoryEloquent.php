<?php

namespace App\Repositories\Eloquent;

use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Repository\Criteria\RequestCriteria;
use App\Repositories\Contracts\ServiceRepository;
use App\Models\Service;

/**
 * Class ServiceRepositoryEloquent.
 *
 * @package namespace App\Repositories\Eloquent;
 */
class ServiceRepositoryEloquent extends BaseRepository implements ServiceRepository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return Service::class;
    }

    public function getAll(){
        $data = Service::where('status', 'active')->get();
        return $data;
    }

    public function GetDetail($slug){
        $data =Service::where('slug', $slug)->get();
        return $data;
    }
    /**
     * Boot up the repository, pushing criteria
     */
    public function boot()
    {
        $this->pushCriteria(app(RequestCriteria::class));
    }

    public function getLimit($limit)
    {
        return $this->model->active()->limit($limit)->get();
    }
    
}
