<?php

namespace App\Repositories\Eloquent;

use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Repository\Criteria\RequestCriteria;
use App\Repositories\Contracts\TagRepository;
use App\Models\Tag;

/**
 * Class ProjectRepositoryEloquent.
 *
 * @package namespace App\Repositories\Eloquent;
 */
class TagRepositoryEloquent extends BaseRepository implements TagRepository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return Tag::class;
    }

    public function getProjectWithTag ($tag, $pagination) 
    {
        $tagId = $this->model->where('tag', $tag)->first();

        return $this->model->find($tagId->id)->project()->active()->paginate($pagination);   
    }
    
}
