<?php

namespace App\Repositories\Contracts;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ProjectCategoryRepository.
 *
 * @package namespace App\Repositories\Contracts;
 */
interface ProjectCategoryRepository extends RepositoryInterface
{
    public function getAll();
}
