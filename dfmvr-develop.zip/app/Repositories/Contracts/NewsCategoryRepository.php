<?php

namespace App\Repositories\Contracts;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface NewsCategoryRepository.
 *
 * @package namespace App\Repositories\Contracts;
 */
interface NewsCategoryRepository extends RepositoryInterface
{
    //
}
