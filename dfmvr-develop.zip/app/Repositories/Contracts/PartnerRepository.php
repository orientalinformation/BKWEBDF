<?php

namespace App\Repositories\Contracts;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PartnerRepository.
 *
 * @package namespace App\Repositories\Contracts;
 */
interface PartnerRepository extends RepositoryInterface
{
    public function getPartners();
}
