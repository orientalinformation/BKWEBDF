<?php

namespace App\Repositories\Contracts;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ServiceRepository.
 *
 * @package namespace App\Repositories\Contracts;
 */
interface TagRepository extends RepositoryInterface
{

}
