<?php

namespace App\Models;

use App\Models\AbstractModel;
use Cviebrock\EloquentSluggable\Sluggable;
use TCG\Voyager\Traits\Translatable;

/**
 * Class Partner.
 *
 * @package namespace App\Models;
 */
class Partner extends AbstractModel
{

    use Translatable;
    
    protected $translatable = ['name', 'description'];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [];

    public function sluggable()
    {
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }

    public function defaultThumb()
    {
        return asset('/frontend/images/icon/icon-sv1.png');
    }

}
