<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tag extends Model
{

    // protected $translatable = ['tag'];

    protected $fillable = [
        'tag',
    ];

    protected $guarded = [];

    public function project()
    {
        return $this->belongsToMany(\App\Models\Project::class, 'project_tags', 'tag_id', 'project_id');
    }

}
