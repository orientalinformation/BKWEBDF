<?php

namespace App\Models;

use App\Models\Trails\Seoable;
use Illuminate\Database\Eloquent\Model;
use TCG\Voyager\Traits\Translatable;
use App\Models\AbstractModel;

class Project extends AbstractModel
{
    use Translatable, Seoable;

    protected $translatable = ['title', 'description', 'content'];

    /**
     * Statuses.
     */
    const STATUS_ACTIVE = 'ACTIVE';
    const STATUS_INACTIVE = 'INACTIVE';

    /**
     * List of statuses.
     *
     * @var array
     */
    public static $statuses = [self::STATUS_ACTIVE, self::STATUS_INACTIVE];

    protected $guarded = [];

    /**
     * Scope a query to only include active pages.
     *
     * @param  $query  \Illuminate\Database\Eloquent\Builder
     *
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where('status', static::STATUS_ACTIVE);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function categoryId()
    {
        return $this->belongsTo(\App\Models\ProjectCategory::class, 'category_id');
    }

    public function defaultThumb()
    {
        return asset('/frontend/images/banner/project1.png');
    }

    public function categories()
    {
        return $this->belongsToMany(ProjectCategory::class, 'project_project_categories', 'project_id', 'project_category_id');
    }

    public function tags()
    {
        return $this->belongsToMany(\App\Models\Tag::class, 'project_tags', 'project_id', 'tag_id');
    }

}
