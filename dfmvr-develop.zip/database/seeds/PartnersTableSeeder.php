<?php

use Illuminate\Database\Seeder;
use TCG\Voyager\Models\DataRow;
use TCG\Voyager\Models\DataType;
use TCG\Voyager\Models\Menu;
use TCG\Voyager\Models\MenuItem;
use TCG\Voyager\Models\Permission;
use App\Models\Partner;

class PartnersTableSeeder extends Seeder
{
    /**
     * Auto generated seed file.
     */
    public function run()
    {
        $env = app()->environment();

        if ($env == 'local'){
            $this->createData();
        }

        //Data Type
        $dataType = $this->dataType('slug', 'partners');
        if (!$dataType->exists) {
            $dataType->fill([
                'name'                  => 'partners',
                'display_name_singular' => 'partner',
                'display_name_plural'   => 'partners',
                'icon'                  => 'voyager-news',
                'model_name'            => 'App\\Models\\Partner',
                'policy_name'           => 'TCG\\Voyager\\Policies\\PostPolicy',
                'controller'            => '',
                'generate_permissions'  => 1,
                'description'           => '',
            ])->save();
        }

        //Data Rows
        $partnerDataType = DataType::where('slug', 'partners')->firstOrFail();
        $dataRow = $this->dataRow($partnerDataType, 'id');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'number',
                'display_name' => 'ID',
                'required'     => 1,
                'browse'       => 0,
                'read'         => 0,
                'edit'         => 0,
                'add'          => 0,
                'delete'       => 0,
                'order'        => 1,
            ])->save();
        }

        $dataRow = $this->dataRow($partnerDataType, 'name');
        if (!$dataRow->exists or true) {
            $dataRow->fill([
                'type'         => 'text',
                'display_name' => 'Name',
                'required'     => 1,
                'browse'       => 1,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'details'      => [
                    'validation' => [
                        'rule'  => 'required',
                    ],
                ],
                'order'        => 2,
            ])->save();
        }

        $dataRow = $this->dataRow($partnerDataType, 'description');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'text_area',
                'display_name' => 'Description',
                'required'     => 0,
                'browse'       => 1,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'order'        => 3,
            ])->save();
        }

        $dataRow = $this->dataRow($partnerDataType, 'link');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'text',
                'display_name' => 'Link',
                'required'     => 0,
                'browse'       => 1,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'order'        => 4,
            ])->save();
        }

        $dataRow = $this->dataRow($partnerDataType, 'slug');
        if (!$dataRow->exists or true) {
            $dataRow->fill([
                'type'         => 'text',
                'display_name' => 'Slug',
                'required'     => 1,
                'browse'       => 0,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'details'      => [
                    'slugify' => [
                        'origin'      => 'name'
                    ],
                    'validation' => [
                        'rule'  => 'unique:partners,slug',
                    ],
                ],
                'order'        => 5,
            ])->save();
        }

        $dataRow = $this->dataRow($partnerDataType, 'image');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'image',
                'display_name' => 'Image',
                'required'     => 0,
                'browse'       => 1,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'order'        => 6,
            ])->save();
        }

        $dataRow = $this->dataRow($partnerDataType, 'position');
        if (!$dataRow->exists or true) {
            $dataRow->fill([
                'type'         => 'select_dropdown',
                'display_name' => 'Position',
                'required'     => 1,
                'browse'       => 0,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'details'      => [
                    'default' => '1',
                    'options' => [
                        '1' => '1',
                        '2' => '2',
                    ],
                ],
                'order'        => 7,
            ])->save();
        }

        $dataRow = $this->dataRow($partnerDataType, 'active');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'select_dropdown',
                'display_name' => __('voyager::seeders.data_rows.status'),
                'required'     => 1,
                'browse'       => 1,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'details'      => [
                    'default' => 'ACTIVE',
                    'options' => [
                        'INACTIVE' => 'INACTIVE',
                        'ACTIVE'   => 'ACTIVE',
                    ],
                ],
                'order' => 8,
            ])->save();
        }

        $dataRow = $this->dataRow($partnerDataType, 'created_at');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'timestamp',
                'display_name' => __('voyager::seeders.data_rows.created_at'),
                'required'     => 1,
                'browse'       => 1,
                'read'         => 1,
                'edit'         => 0,
                'add'          => 0,
                'delete'       => 0,
                'order'        => 9,
            ])->save();
        }

        $dataRow = $this->dataRow($partnerDataType, 'updated_at');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'timestamp',
                'display_name' => __('voyager::seeders.data_rows.updated_at'),
                'required'     => 1,
                'browse'       => 0,
                'read'         => 0,
                'edit'         => 0,
                'add'          => 0,
                'delete'       => 0,
                'order'        => 10,
            ])->save();
        }

        //Menu Item
        $menu = Menu::where('name', 'admin')->firstOrFail();
        $menuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => 'Partners',
            'url'     => '/admin/partners',
            'route'   => 'voyager.partners.index',
        ]);
        if (!$menuItem->exists) {
            $menuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-news',
                'color'      => null,
                'parent_id'  => null,
                'order'      => 8,
            ])->save();
        }

        //Permissions
        Permission::generateFor('partners');
    }

    /**
     * [post description].
     *
     * @param [type] $slug [description]
     *
     * @return [type] [description]
     */
    protected function findPost($slug)
    {
        return Partner::firstOrNew(['slug' => $slug]);
    }

    /**
     * [dataRow description].
     *
     * @param [type] $type  [description]
     * @param [type] $field [description]
     *
     * @return [type] [description]
     */
    protected function dataRow($type, $field)
    {
        return DataRow::firstOrNew([
            'data_type_id' => $type->id,
            'field'        => $field,
        ]);
    }

    /**
     * [dataType description].
     *
     * @param [type] $field [description]
     * @param [type] $for   [description]
     *
     * @return [type] [description]
     */
    protected function dataType($field, $for)
    {
        return DataType::firstOrNew([$field => $for]);
    }

    protected function createData()
    {
        $data = [
            [
                    'name'              => 'Xe buýt thông minh 1',
                    'description'       => 'Hệ thống bán vé và quản lý vận hành trực tuyến cho các nhà xe.',
            ],
            [
                    'name'              => 'Xe buýt thông minh 2',
                    'description'       => 'Hệ thống bán vé và quản lý vận hành trực tuyến cho các nhà xe.',
            ],
            [
                    'name'              => 'Xe buýt thông minh 3',
                    'description'       => 'Hệ thống bán vé và quản lý vận hành trực tuyến cho các nhà xe.',
            ],
            [
                    'name'              => 'Xe buýt thông minh 4',
                    'description'       => 'Hệ thống bán vé và quản lý vận hành trực tuyến cho các nhà xe.',
            ],
            [
                    'name'              => 'Xe buýt thông minh 5',
                    'description'       => 'Hệ thống bán vé và quản lý vận hành trực tuyến cho các nhà xe.',
            ],
            [
                    'name'              => 'Xe buýt thông minh 6',
                    'description'       => 'Hệ thống bán vé và quản lý vận hành trực tuyến cho các nhà xe.',
            ]
        ];

        foreach ($data as $item) {
            $item_update = $item;
            unset($item_update['name']);
            $item_update['slug'] = str_slug($item['name']);
            $item_update['link'] = 'https://360.tdtu.edu.vn/library/';
            $item_update['active'] = 'ACTIVE';

            Partner::updateOrCreate(['name' => $item['name']], $item_update);
        }
    }
}
