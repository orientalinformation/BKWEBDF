<?php

use Illuminate\Database\Seeder;
use TCG\Voyager\Models\Category;
use TCG\Voyager\Models\DataType;
use TCG\Voyager\Models\Menu;
use TCG\Voyager\Models\MenuItem;
use TCG\Voyager\Models\Page;
use TCG\Voyager\Models\Translation;

class TranslationsTableSeeder extends Seeder
{
    /**
     * Auto generated seed file.
     *
     * @return void
     */
    public function run()
    {
        $this->dataTypesTranslations();
//        $this->categoriesTranslations();
        $this->pagesTranslations();
        $this->menusTranslations();
        $this->userMenusTranslations();
        $this->newsCategoryTranslations();
        $this->projectsCategoryTranslations();
        $this->serviceTranslations();
    }

    /**
     * Auto generate Categories Translations.
     *
     * @return void
     */
    private function categoriesTranslations()
    {
        // Adding translations for 'categories'
        //
        $cat = Category::where('slug', 'category-1')->firstOrFail();
        if ($cat->exists) {
            $this->trans('fr', $this->arr(['categories', 'slug'], $cat->id), 'categoria-1');
            $this->trans('fr', $this->arr(['categories', 'name'], $cat->id), 'Catégorie 1');
        }
        $cat = Category::where('slug', 'category-2')->firstOrFail();
        if ($cat->exists) {
            $this->trans('fr', $this->arr(['categories', 'slug'], $cat->id), 'categoria-2');
            $this->trans('fr', $this->arr(['categories', 'name'], $cat->id), 'Catégorie 2');
        }
    }

    /**
     * Auto generate DataTypes Translations.
     *
     * @return void
     */
    private function dataTypesTranslations()
    {
        // Adding translations for 'display_name_singular'
        //
        $_fld = 'display_name_singular';
        $_tpl = ['data_types', $_fld];
        /*$dtp = DataType::where($_fld, 'Post')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Poster');
        }*/
        $dtp = DataType::where($_fld, 'Page')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Page');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Trang');
        }
        $dtp = DataType::where($_fld, 'User')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Utilisateur');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Người dùng');
        }
        /*$dtp = DataType::where($_fld, 'Category')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Catégorie');
        }*/
        $dtp = DataType::where($_fld, 'Menu')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Menu');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Thực đơn');
        }
        $dtp = DataType::where($_fld, 'Role')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Rôle');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Vai trò');
        }
        $dtp = DataType::where($_fld, 'Project Category')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Catégorie de projet');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Danh mục dự án');
        }
        $dtp = DataType::where($_fld, 'Project')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Projet');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Dự án');
        }
        $dtp = DataType::where($_fld, 'News Category')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Catégorie de actualités');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Danh mục tin tức');
        }
        $dtp = DataType::where($_fld, 'News')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Actualités');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Tin tức');
        }
        $dtp = DataType::where($_fld, 'Service')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Service');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Dịch vụ');
        }
        $dtp = DataType::where($_fld, 'Service Model')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Modèle de service');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Mô hình dịch vụ');
        }

        // Adding translations for 'display_name_plural'
        //
        $_fld = 'display_name_plural';
        $_tpl = ['data_types', $_fld];
        /*$dtp = DataType::where($_fld, 'Posts')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Postes');
        }*/
        $dtp = DataType::where($_fld, 'Pages')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Pages');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Trang');
        }
        $dtp = DataType::where($_fld, 'Users')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Utilisateurs');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Người dùng');
        }
        /*$dtp = DataType::where($_fld, 'Categories')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Catégories');
        }*/
        $dtp = DataType::where($_fld, 'Menus')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Menus');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Thực đơn');
        }
        $dtp = DataType::where($_fld, 'Roles')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Rôles');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Vai trò');
        }
        $dtp = DataType::where($_fld, 'Project Categories')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Catégories de projets');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Danh mục dự án');
        }
        $dtp = DataType::where($_fld, 'Projects')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Projets');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Dự án');
        }
        $dtp = DataType::where($_fld, 'News Categories')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Catégories de actualités');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Danh mục tin tức');
        }
        $dtp = DataType::where($_fld, 'News')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Actualités');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Tin tức');
        }
        $dtp = DataType::where($_fld, 'Services')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Services');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Dịch vụ');
        }
        $dtp = DataType::where($_fld, 'Service Models')->firstOrFail();
        if ($dtp->exists) {
            $this->trans('fr', $this->arr($_tpl, $dtp->id), 'Modèles de service');
            $this->trans('vi', $this->arr($_tpl, $dtp->id), 'Mô hình dịch vụ');
        }
    }

    /**
     * Auto generate Pages Translations.
     *
     * @return void
     */
    private function pagesTranslations()
    {
        $page = Page::where('slug', 'introduce')->firstOrFail();
        if ($page->exists) {
            $_arr = $this->arr(['pages', 'title'], $page->id);
            $this->trans('fr', $_arr, 'Introduce');
            $this->trans('en', $_arr, 'Introduce');
            // $this->trans('vi', $_arr, 'Giới thiệu');
            /**
             * For configuring additional languages use it e.g.
             *
             * ```
             *   $this->trans('es', $_arr, 'hola-mundo');
             *   $this->trans('de', $_arr, 'hallo-welt');
             * ```
             */
            // $_arr = $this->arr(['pages', 'slug'], $page->id);
            // $this->trans('fr', $_arr, 'introduce');
            // $this->trans('vi', $_arr, 'introduce');

            $_arr = $this->arr(['pages', 'body'], $page->id);
            $this->trans('fr', $_arr, '<p>Spécialisé dans la fourniture de services liés à la technologie de réalité virtuell
                                    DFM-VR, du groupe DFM est un acteur majeur dans la haute technologie, apportant des solutions immersives et interactives clé en main et sur mesure dans les systèmes d’information, du conseil et de l’expertise.</p>

                                    <p>De l’idée au développement, puis le commercialisation, DFM-VR vous offre des solutions de Réalité Virtuelle et Réalité Augmentée adaptés à vos besoins et intégrables sans peine aux secteurs les plus compétitives du marché que ce soit sur la partie hardware et/ou sur notre solution software.</p>');
            $this->trans('en', $_arr, '<p>DFM VR works in the field of consulting, design and providing the solutions for website 3D, VR and AR technology.</p><p>
                                        We always work hard to  bring our customers a virtual reality experience in the professional way.</p><p>
                                        DFM Engineering established in 2006 with a team of experts including 100 engineers, masters and PhDs.</p><p>
                                        We understand the challenges presenting in the future. With DFM VR, the future is now and it is becoming realist through virtual reality technology solutions, software development, hardware provisioning and project completion on schedule.</p>');
        }
    }

    /**
     * Auto generate Menus Translations.
     *
     * @return void
     */
    private function menusTranslations()
    {
        $_tpl = ['menu_items', 'title'];
        $_item = $this->findMenuItem('Dashboard');
        if ($_item->exists) {
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Tableau de bord');
            $this->trans('vi', $this->arr($_tpl, $_item->id), 'Bảng điều khiển');
        }

        $_item = $this->findMenuItem('Media');
        if ($_item->exists) {
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Médias');
            $this->trans('vi', $this->arr($_tpl, $_item->id), 'Đa phương tiện');
        }

        /*$_item = $this->findMenuItem('Posts');
        if ($_item->exists) {
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Postes');
        }*/

        $_item = $this->findMenuItem('Users');
        if ($_item->exists) {
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Utilisateurs');
            $this->trans('vi', $this->arr($_tpl, $_item->id), 'Người dùng');
        }

        $_items = $this->findMenuItems('Categories');
        foreach ($_items as $_item) {
            if ($_item->exists) {
                $this->trans('fr', $this->arr($_tpl, $_item->id), 'Catégories');
                $this->trans('vi', $this->arr($_tpl, $_item->id), 'Danh mục');
            }
        }

        $_item = $this->findMenuItem('Pages');
        if ($_item->exists) {
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Pages');
            $this->trans('vi', $this->arr($_tpl, $_item->id), 'Trang');
        }

        $_item = $this->findMenuItem('Roles');
        if ($_item->exists) {
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Rôles');
            $this->trans('vi', $this->arr($_tpl, $_item->id), 'Vai trò');
        }

        $_item = $this->findMenuItem('Tools');
        if ($_item->exists) {
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Outils');
            $this->trans('vi', $this->arr($_tpl, $_item->id), 'Công cụ');
        }

        $_item = $this->findMenuItem('Menu Builder');
        if ($_item->exists) {
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Menus');
            $this->trans('vi', $this->arr($_tpl, $_item->id), 'Thực đơn');
        }

        $_item = $this->findMenuItem('Database');
        if ($_item->exists) {
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Base de données');
            $this->trans('vi', $this->arr($_tpl, $_item->id), 'Cơ sở dữ liệu');
        }

        $_item = $this->findMenuItem('Settings');
        if ($_item->exists) {
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Réglages');
            $this->trans('vi', $this->arr($_tpl, $_item->id), 'Cài đặt');
        }

        $_item = $this->findMenuItem('Projects');
        if ($_item->exists) {
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Projets');
            $this->trans('vi', $this->arr($_tpl, $_item->id), 'Dự án');
        }

        $_item = $this->findMenuItem('News');
        if ($_item->exists) {
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Actualités');
            $this->trans('vi', $this->arr($_tpl, $_item->id), 'Tin tức');
        }

        $_item = $this->findMenuItem('Services');
        if ($_item->exists) {
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Services');
            $this->trans('vi', $this->arr($_tpl, $_item->id), 'Dịch vụ');
        }

        $_item = $this->findMenuItem('Models');
        if ($_item->exists) {
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Modèles');
            $this->trans('vi', $this->arr($_tpl, $_item->id), 'Mô hình');
        }

        $_items = $this->findMenuItems('List');
        foreach ($_items as $_item) {
            if ($_item->exists) {
                $this->trans('fr', $this->arr($_tpl, $_item->id), 'Liste');
                $this->trans('vi', $this->arr($_tpl, $_item->id), 'Danh sách');
            }
        }
    }

    /**
     * Auto generate User Menus Translations.
     */
    private function userMenusTranslations()
    {
        $_tpl = ['menu_items', 'title'];
        $userMenu = Menu::where('name', 'user')->firstOrFail();

        $_item = MenuItem::whereMenuId($userMenu->id)->whereTitle('Trang chủ')->firstOrFail();
        if ($_item->exists) {
            $this->trans('en', $this->arr($_tpl, $_item->id), 'Home');
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Accueil');
        }

        $_item = MenuItem::whereMenuId($userMenu->id)->whereTitle('Giới thiệu')->firstOrFail();
        if ($_item->exists) {
            $this->trans('en', $this->arr($_tpl, $_item->id), 'Introduce');
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'À Propos');
        }

        $_item = MenuItem::whereMenuId($userMenu->id)->whereTitle('Dịch vụ')->firstOrFail();
        if ($_item->exists) {
            $this->trans('en', $this->arr($_tpl, $_item->id), 'Services');
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Services');
        }

        $_item = MenuItem::whereMenuId($userMenu->id)->whereTitle('Dự án')->firstOrFail();
        if ($_item->exists) {
            $this->trans('en', $this->arr($_tpl, $_item->id), 'Projects');
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Projets');
        }

        $_item = MenuItem::whereMenuId($userMenu->id)->whereTitle('Tin tức')->firstOrFail();
        if ($_item->exists) {
            $this->trans('en', $this->arr($_tpl, $_item->id), 'News');
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Actualités');
        }

        $_item = MenuItem::whereMenuId($userMenu->id)->whereTitle('Liên hệ')->firstOrFail();
        if ($_item->exists) {
            $this->trans('en', $this->arr($_tpl, $_item->id), 'Contact');
            $this->trans('fr', $this->arr($_tpl, $_item->id), 'Contact');
        }
    }

    private function findMenuItem($title)
    {
        return MenuItem::where('title', $title)->firstOrFail();
    }

    private function findMenuItems($title)
    {
        return MenuItem::where('title', $title)->get();
    }

    private function arr($par, $id)
    {
        return [
            'table_name'  => $par[0],
            'column_name' => $par[1],
            'foreign_key' => $id,
        ];
    }

    private function trans($lang, $keys, $value)
    {
        $_t = Translation::firstOrNew(array_merge($keys, [
            'locale' => $lang,
        ]));

        if (!$_t->exists) {
            $_t->fill(array_merge(
                $keys,
                ['value' => $value]
            ))->save();
        }
    }

    private function newsCategoryTranslations()
    {
        $page = App\Models\NewsCategory::where('slug', 'application')->firstOrFail();
        if ($page->exists) {
            $_arr = $this->arr(['news_categories', 'name'], $page->id);
            $this->trans('fr', $_arr, 'Application');
            $this->trans('en', $_arr, 'Application');
        }
        $page1 = App\Models\NewsCategory::where('slug', 'events')->firstOrFail();
        if ($page1->exists) {
            $_arr = $this->arr(['news_categories', 'name'], $page1->id);
            $this->trans('fr', $_arr, 'événements');
            $this->trans('en', $_arr, 'Events');
        }
        $page2 = App\Models\NewsCategory::where('slug', 'technology')->firstOrFail();
        if ($page2->exists) {
            $_arr = $this->arr(['news_categories', 'name'], $page2->id);
            $this->trans('fr', $_arr, 'La technologie');
            $this->trans('en', $_arr, 'Technology');
        }
    }
    private function projectsCategoryTranslations()
    {
        $page = App\Models\ProjectCategory::where('slug', 'real-estate')->firstOrFail();
        if ($page->exists) {
            $_arr = $this->arr(['project_categories', 'name'], $page->id);
            $this->trans('fr', $_arr, 'Immobilier');
            $this->trans('en', $_arr, 'Real Estate');
        }
        $page1 = App\Models\ProjectCategory::where('slug', 'prototyping')->firstOrFail();
        if ($page1->exists) {
            $_arr = $this->arr(['project_categories', 'name'], $page1->id);
            $this->trans('fr', $_arr, 'Prototypage');
            $this->trans('en', $_arr, 'Prototyping');
        }
        $page2 = App\Models\ProjectCategory::where('slug', 'tourism')->firstOrFail();
        if ($page2->exists) {
            $_arr = $this->arr(['project_categories', 'name'], $page2->id);
            $this->trans('fr', $_arr, 'Tourisme');
            $this->trans('en', $_arr, 'Tourism');
        }
        $page3 = App\Models\ProjectCategory::where('slug', 'design')->firstOrFail();
        if ($page3->exists) {
            $_arr = $this->arr(['project_categories', 'name'], $page3->id);
            $this->trans('fr', $_arr, 'Conception');
            $this->trans('en', $_arr, 'Design');
        }
        $page4 = App\Models\ProjectCategory::where('slug', 'education')->firstOrFail();
        if ($page4->exists) {
            $_arr = $this->arr(['project_categories', 'name'], $page4->id);
            $this->trans('fr', $_arr, 'Éducation');
            $this->trans('en', $_arr, 'Education');
        }
    }

    private function serviceTranslations()
    {
        $page = App\Models\Service::where('slug', 'capture-360')->firstOrFail();
        if ($page->exists) {
            $_arr = $this->arr(['services', 'title'], $page->id);
            $this->trans('fr', $_arr, 'CAPTURE 3D 360');
            $this->trans('en', $_arr, 'CAPTURE 3D 360');
        }
        $page1 = App\Models\Service::where('slug', 'prototyping')->firstOrFail();
        if ($page1->exists) {
            $_arr = $this->arr(['services', 'title'], $page1->id);
            $this->trans('fr', $_arr, 'APPLICATION VR');
            $this->trans('en', $_arr, 'VR APPLICATION');
        }
        $page2 = App\Models\Service::where('slug', 'ar-application')->firstOrFail();
        if ($page2->exists) {
            $_arr = $this->arr(['services', 'title'], $page2->id);
            $this->trans('fr', $_arr, 'APPLICATION AR');
            $this->trans('en', $_arr, 'AR APPLICATION');
        }
        $page3 = App\Models\Service::where('slug', 'components')->firstOrFail();
        if ($page3->exists) {
            $_arr = $this->arr(['services', 'title'], $page3->id);
            $this->trans('fr', $_arr, 'COMPOSANTS');
            $this->trans('en', $_arr, 'COMPONENTS');
        }
    }
}
