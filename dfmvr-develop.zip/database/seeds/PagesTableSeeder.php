<?php

use Illuminate\Database\Seeder;
use TCG\Voyager\Models\DataRow;
use TCG\Voyager\Models\DataType;
use TCG\Voyager\Models\Menu;
use TCG\Voyager\Models\MenuItem;
use App\Models\Page;
use TCG\Voyager\Models\Permission;

class PagesTableSeeder extends Seeder
{
    /**
     * Auto generated seed file.
     *
     * @return void
     */
    public function run()
    {   
        //Data Type
        $dataType = $this->dataType('slug', 'pages');
        if (!$dataType->exists or true) {
            $dataType->fill([
                'name'                  => 'pages',
                'display_name_singular' => __('voyager::seeders.data_types.page.singular'),
                'display_name_plural'   => __('voyager::seeders.data_types.page.plural'),
                'icon'                  => 'voyager-file-text',
                'model_name'            => 'App\\Models\\Page',
                'controller'            => 'App\\Http\\Controllers\\Admin\\PageController',
                'generate_permissions'  => 1,
                'description'           => '',
            ])->save();
        }

        //Data Rows
        $pageDataType = DataType::where('slug', 'pages')->firstOrFail();
        $dataRow = $this->dataRow($pageDataType, 'id');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'number',
                'display_name' => __('voyager::seeders.data_rows.id'),
                'required'     => 1,
                'browse'       => 0,
                'read'         => 0,
                'edit'         => 0,
                'add'          => 0,
                'delete'       => 0,
                'order'        => 1,
            ])->save();
        }

        $dataRow = $this->dataRow($pageDataType, 'author_id');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'text',
                'display_name' => __('voyager::seeders.data_rows.author'),
                'required'     => 1,
                'browse'       => 0,
                'read'         => 0,
                'edit'         => 0,
                'add'          => 0,
                'delete'       => 0,
                'order'        => 2,
            ])->save();
        }

        $dataRow = $this->dataRow($pageDataType, 'title');
        if (!$dataRow->exists or true) {
            $dataRow->fill([
                'type'         => 'text',
                'display_name' => __('voyager::seeders.data_rows.title'),
                'required'     => 1,
                'browse'       => 1,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'details'      => [
                    'validation' => [
                        'rule'  => 'required',
                    ],
                ],
                'order'        => 3,
            ])->save();
        }

        $dataRow = $this->dataRow($pageDataType, 'excerpt');
        if (!$dataRow->exists or true) {
            $dataRow->fill([
                'type'         => 'rich_text_box',
                'display_name' => __('voyager::seeders.data_rows.excerpt'),
                'required'     => 1,
                'browse'       => 0,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'order'        => 4,
            ])->save();
        }

        $dataRow = $this->dataRow($pageDataType, 'body');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'rich_text_box',
                'display_name' => __('voyager::seeders.data_rows.body'),
                'required'     => 1,
                'browse'       => 0,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'order'        => 5,
            ])->save();
        }

        $dataRow = $this->dataRow($pageDataType, 'slug');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'text',
                'display_name' => __('voyager::seeders.data_rows.slug'),
                'required'     => 1,
                'browse'       => 0,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'details'      => [
                    'slugify' => [
                        'origin' => 'title',
                    ],
                    'validation' => [
                        'rule'  => 'unique:pages,slug',
                    ],
                ],
                'order' => 6,
            ])->save();
        }

        // $dataRow = $this->dataRow($pageDataType, 'meta_description');
        // if (!$dataRow->exists) {
        //     $dataRow->fill([
        //         'type'         => 'text',
        //         'display_name' => __('voyager::seeders.data_rows.meta_description'),
        //         'required'     => 1,
        //         'browse'       => 0,
        //         'read'         => 1,
        //         'edit'         => 1,
        //         'add'          => 1,
        //         'delete'       => 1,
        //         'order'        => 7,
        //     ])->save();
        // }

        // $dataRow = $this->dataRow($pageDataType, 'meta_keywords');
        // if (!$dataRow->exists) {
        //     $dataRow->fill([
        //         'type'         => 'text',
        //         'display_name' => __('voyager::seeders.data_rows.meta_keywords'),
        //         'required'     => 1,
        //         'browse'       => 0,
        //         'read'         => 1,
        //         'edit'         => 1,
        //         'add'          => 1,
        //         'delete'       => 1,
        //         'order'        => 8,
        //     ])->save();
        // }

        $dataRow = $this->dataRow($pageDataType, 'status');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'select_dropdown',
                'display_name' => __('voyager::seeders.data_rows.status'),
                'required'     => 1,
                'browse'       => 1,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'details'      => [
                    'default' => 'INACTIVE',
                    'options' => [
                        'INACTIVE' => 'INACTIVE',
                        'ACTIVE'   => 'ACTIVE',
                    ],
                ],
                'order' => 9,
            ])->save();
        }

        $dataRow = $this->dataRow($pageDataType, 'created_at');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'timestamp',
                'display_name' => __('voyager::seeders.data_rows.created_at'),
                'required'     => 1,
                'browse'       => 1,
                'read'         => 1,
                'edit'         => 0,
                'add'          => 0,
                'delete'       => 0,
                'order'        => 10,
            ])->save();
        }

        $dataRow = $this->dataRow($pageDataType, 'updated_at');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'timestamp',
                'display_name' => __('voyager::seeders.data_rows.updated_at'),
                'required'     => 1,
                'browse'       => 0,
                'read'         => 0,
                'edit'         => 0,
                'add'          => 0,
                'delete'       => 0,
                'order'        => 11,
            ])->save();
        }

        $dataRow = $this->dataRow($pageDataType, 'image');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'image',
                'display_name' => __('voyager::seeders.data_rows.page_image'),
                'required'     => 0,
                'browse'       => 1,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'order'        => 12,
            ])->save();
        }

        //Menu Item
        $menu = Menu::where('name', 'admin')->firstOrFail();
        $menuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => __('voyager::seeders.menu_items.pages'),
            'url'     => '',
            'route'   => 'voyager.pages.index',
        ]);
        if (!$menuItem->exists) {
            $menuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-file-text',
                'color'      => null,
                'parent_id'  => null,
                'order'      => 4,
            ])->save();
        }

        //Permissions
        Permission::generateFor('pages');
        //Content

        $page = Page::updateOrCreate(['slug' => 'introduce'],
                [
                'author_id'        => 1,
                'title'            => 'Giới thiệu',
                'excerpt'          => '<h3 class="title">
                                          Xin chào! Chúng tôi là
                                            <span>DFM-VR</span><br>
                                          Chuyên cung cấp dịch vụ liên quan đến
                                            <span>công nghệ thực tế ảo</span>
                                        </h3>',
                'body'             => '<p>DFM VR hoạt động trong lĩnh vực công nghệ, tư vấn, thiết kế, quảng bá bất động sản.</p> <p>Với những công cụ sẵn có và không ngừng tạo ra những công cụ hỗ trợ mới, chúng tôi mang tới cho khách hàng những trải nghiệm thực tế ảo với chất lượng chuyên nghiệp.</p> <p>DFM Engineering được thành lập từ năm 2006 với đội ngũ chuyên gia gồm 100 kỹ sư, thạc sĩ, tiến sĩ có kiến thức chuyên sâu và bề dày kinh nghiệm trong các lĩnh vực hoạt động của công ty. Chúng tôi hiểu rằng tương lai đang nắm giữ nhiều cơ hội bất tận và thú vị. Với DFM VR, tương lai nằm ở hiện tại và đang hiện thực hóa thông qua giải pháp công nghệ thực tế ảo, phát triển phần mềm, cung cấp phần cứng và hoàn thành tốt dự án theo đúng tiến độ</p>',
                'image'            => '',
                'meta_description' => '',
                'meta_keywords'    => '',
                'status'           => 'ACTIVE',
            ]
        );

        $page = Page::updateOrCreate(['slug' => '360-active'],
                [
                'author_id'        => 1,
                'title'            => 'block service 360',
                'excerpt'          => 'Lợi ích ứng dụng chụp hình 360',
                'body'             => '<ul> <li>Lột tả toàn bộ nét đặc sắc của khùng cảnh, sản phẩm. Không gian hiển thị hình ảnh trên cả 3 chiều.</li>
                                        <li>Trải nghiệm linh động, thúc đẩy trí tưởng tượng thông qua hiển thị ấn tượng và sống động. Tích hợp trên website, các dòng điện thoại thông minh, Samsung gear, HTC Vive...</li>
                                        <li>Thiết lập tour tham quan ảo linh động, thu hút sự chú ý của khách hàng. Tạo lợi thế cạnh tranh cho doanh nghiệp.</li></ul>',
                'image'            => '',
                'meta_description' => '',
                'meta_keywords'    => '',
                'status'           => 'ACTIVE',
            ]
        );

        $page = Page::updateOrCreate(['slug' => 'technology-AR'],
                [
                'author_id'        => 1,
                'title'            => 'Block technology AR',
                'excerpt'          => '',
                'body'             => '<h3>Ứng dụng công nghệ AR</h3>
                                    Bằng cách dùng camera quét qua các hình ảnh 2D hoặc các vật thể, thông qua ứng dụng này. Sản phẩm của công ty bạn có thể hiện bằng hình ảnh 3D. Bạn hoàn toàn có thể thay đổi màu sắc cũng như kích cỡ sản phẩm dự trên các lựa chọn có sẵn. Ví dụ, đối với các ngành sản phẩm như tượng đồng, đồ cổ, đồ trang trí nội thất, việc mang theo sản phẩm để giới thiệu với khách hàng gặp phải khó khăn do sản phẩm thường có kích thước lớn. Tuy nhiên, hiên nay chỉ với một cuốn catalogue, mọi sản phẩm có thể hiện ra trước mặt khách hàng. Bạn thậm chí có thể tạo ra một showroom ảo để trưng bày các sản phẩm của bạn.',
                'image'            => '',
                'meta_description' => '',
                'meta_keywords'    => '',
                'status'           => 'ACTIVE',
            ]
        );


        $page = Page::updateOrCreate(['slug' => '360-block'],
                [
                'author_id'        => 1,
                'title'            => '360 Block',
                'excerpt'          => '',
                'body'             => '<div class="cooperate mt-5">
                                        <div class="row mb-4">
                                            <div class="col-lg-4 col-12 col-md-12">
                                                <h2 class="cooperate-tt mt-4">Cơ hội hợp tác <span>của tương lai</span></h2>
                                                <p class="cooperate-content">Ứng dụng công nghệ chụp hình 360 vào việc quảng bá website, các sản phẩm dịch vụ đã trở thành xu hướng công nghệ tương lai</p>
                                            </div>
                                            <div class="col-lg-8 col-12 col-sm-12 col-md-12">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="cooperate-hotel text-center">
                                                            <span class="cooperate-title">Nhà hàng - Khách sạn</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 mb-top">
                                                        <div class="cooperate-property">
                                                            <span class="cooperate-title">Bất động sản</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row t2">
                                                    <div class="col-md-6">
                                                        <div class="cooperate-travel">
                                                            <span class="cooperate-title">Du lịch</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 mb-top">
                                                        <div class="cooperate-product">
                                                            <span class="cooperate-title">Sản phẩm khác</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <a href="http://beta.dfm-vr.com/projects"><span class="cooperate-more">Xem thêm các dự án &gt;&gt;</span></a>
                                    </div>',
                'image'            => '',
                'meta_description' => '',
                'meta_keywords'    => '',
                'status'           => 'ACTIVE',
            ]
        );
        
        
    }

    /**
     * [dataRow description].
     *
     * @param [type] $type  [description]
     * @param [type] $field [description]
     *
     * @return [type] [description]
     */
    protected function dataRow($type, $field)
    {
        return DataRow::firstOrNew([
                'data_type_id' => $type->id,
                'field'        => $field,
            ]);
    }

    /**si laborum sed. Sequi praesentium et praesentium aut excepturi ratione ut ad. Iste id id placeat ab. Molestiae distinctio sapiente occaecati numquam voluptas.
Et quia inventore quas consectetur. Repellat non corrupti eius harum debitis. Voluptatum impedit sit culpa suscipit quo.
Eum sint perspiciatis corporis qui omnis velit. Pariatur quis est tenetur et tempora tempora. Nobis omnis sint cumque consequuntur.
Quibusdam corporis reprehenderit animi et praesentium sit. Earum sunt non maiores molestiae quibusdam. Ut et magni commodi at et doloremque.
     * [dataType description].
     *
     * @param [type] $field [description]
     * @param [type] $for   [description]
     *
     * @return [type] [description]
     */
    protected function dataType($field, $for)
    {
        return DataType::firstOrNew([$field => $for]);
    }
}
