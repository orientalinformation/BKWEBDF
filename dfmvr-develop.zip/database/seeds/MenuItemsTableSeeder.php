<?php

use Illuminate\Database\Seeder;
use TCG\Voyager\Models\Menu;
use TCG\Voyager\Models\MenuItem;

class MenuItemsTableSeeder extends Seeder
{
    /**
     * Auto generated seed file.
     *
     * @return void
     */
    public function run()
    {
        $menu = Menu::where('name', 'admin')->firstOrFail();

        $menuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => __('voyager::seeders.menu_items.dashboard'),
            'url'     => '',
            'route'   => 'voyager.dashboard',
        ]);
        if (!$menuItem->exists) {
            $menuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-boat',
                'color'      => null,
                'parent_id'  => null,
                'order'      => 1,
            ])->save();
        }

        $menuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => __('voyager::seeders.menu_items.media'),
            'url'     => '',
            'route'   => 'voyager.media.index',
        ]);
        if (!$menuItem->exists) {
            $menuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-images',
                'color'      => null,
                'parent_id'  => null,
                'order'      => 5,
            ])->save();
        }

        $menuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => __('voyager::seeders.menu_items.users'),
            'url'     => '',
            'route'   => 'voyager.users.index',
        ]);
        if (!$menuItem->exists) {
            $menuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-person',
                'color'      => null,
                'parent_id'  => null,
                'order'      => 3,
            ])->save();
        }

        $menuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => __('voyager::seeders.menu_items.roles'),
            'url'     => '',
            'route'   => 'voyager.roles.index',
        ]);
        if (!$menuItem->exists) {
            $menuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-lock',
                'color'      => null,
                'parent_id'  => null,
                'order'      => 2,
            ])->save();
        }

        $toolsMenuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => __('voyager::seeders.menu_items.tools'),
            'url'     => '',
        ]);
        if (!$toolsMenuItem->exists) {
            $toolsMenuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-tools',
                'color'      => null,
                'parent_id'  => null,
                'order'      => 9,
            ])->save();
        }

        $menuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => __('voyager::seeders.menu_items.menu_builder'),
            'url'     => '',
            'route'   => 'voyager.menus.index',
        ]);
        if (!$menuItem->exists) {
            $menuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-list',
                'color'      => null,
                'parent_id'  => $toolsMenuItem->id,
                'order'      => 10,
            ])->save();
        }

        $menuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => __('voyager::seeders.menu_items.database'),
            'url'     => '',
            'route'   => 'voyager.database.index',
        ]);
        if (!$menuItem->exists) {
            $menuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-data',
                'color'      => null,
                'parent_id'  => $toolsMenuItem->id,
                'order'      => 11,
            ])->save();
        }

        $menuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => __('voyager::seeders.menu_items.compass'),
            'url'     => '',
            'route'   => 'voyager.compass.index',
        ]);
        if (!$menuItem->exists) {
            $menuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-compass',
                'color'      => null,
                'parent_id'  => $toolsMenuItem->id,
                'order'      => 12,
            ])->save();
        }

        $menuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => __('voyager::seeders.menu_items.bread'),
            'url'     => '',
            'route'   => 'voyager.bread.index',
        ]);
        if (!$menuItem->exists) {
            $menuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-bread',
                'color'      => null,
                'parent_id'  => $toolsMenuItem->id,
                'order'      => 13,
            ])->save();
        }

        $menuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => __('voyager::seeders.menu_items.settings'),
            'url'     => '',
            'route'   => 'voyager.settings.index',
        ]);
        if (!$menuItem->exists) {
            $menuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-settings',
                'color'      => null,
                'parent_id'  => null,
                'order'      => 14,
            ])->save();
        }

        $projectsMenuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => 'Projects',
            'url'     => '',
            'route'   => null
        ]);
        if (!$projectsMenuItem->exists) {
            $projectsMenuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-documentation',
                'color'      => null,
                'parent_id'  => null,
                'order'      => 8,
            ])->save();
        }

        $newsMenuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => 'News',
            'url'     => '',
            'route'   => null
        ]);
        if (!$newsMenuItem->exists) {
            $newsMenuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-news',
                'color'      => null,
                'parent_id'  => null,
                'order'      => 8,
            ])->save();
        }

        $servicesMenuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => 'Services',
            'url'     => '',
            'route'   => null
        ]);
        if (!$servicesMenuItem->exists) {
            $servicesMenuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-truck',
                'color'      => null,
                'parent_id'  => null,
                'order'      => 8,
            ])->save();
        }

        $this->createUserMenu();
    }

    private function createUserMenu()
    {
        $userMenu = Menu::where('name', 'user')->firstOrFail();
        MenuItem::where('menu_id', $userMenu->id)->delete();

        MenuItem::updateOrCreate([
            'menu_id'   => $userMenu->id,
            'title'     => 'Trang chủ',
        ], [
            'url'       => '/',
            'route'     => 'index',
            'target'    => '_self',
            'parent_id' => null,
            'order'     => 1,
        ]);

        MenuItem::updateOrCreate([
            'menu_id'   => $userMenu->id,
            'title'     => 'Giới thiệu',
        ], [
            'url'       => '/pages/introduce',
            'route'     => 'page.index',
            'parameters' => '{"slug":"introduce"}',
            'target'    => '_self',
            'parent_id' => null,
            'order'     => 2,
        ]);

        MenuItem::updateOrCreate([
            'menu_id'   => $userMenu->id,
            'title'     => 'Dịch vụ',
        ], [
            'url'       => '/services',
            'route'     => 'service.index',
            'target'    => '_self',
            'parent_id' => null,
            'order'     => 3,
        ]);

        MenuItem::updateOrCreate([
            'menu_id'   => $userMenu->id,
            'title'     => 'Dự án',
        ], [
            'url'       => '/projects',
            'route'     => 'project.index',
            'target'    => '_self',
            'parent_id' => null,
            'order'     => 4,
        ]);

        MenuItem::updateOrCreate([
            'menu_id'   => $userMenu->id,
            'title'     => 'Tin tức',
        ], [
            'url'       => '/news',
            'route'     => 'news.index',
            'target'    => '_self',
            'parent_id' => null,
            'order'     => 5,
        ]);

        MenuItem::updateOrCreate([
            'menu_id'   => $userMenu->id,
            'title'     => 'Liên hệ',
        ], [
            'url'       => '/contact',
            'route'     => 'contact',
            'target'    => '_self',
            'parent_id' => null,
            'order'     => 6,
        ]);
    }
}
