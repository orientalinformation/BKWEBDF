<?php

use Illuminate\Database\Seeder;
use TCG\Voyager\Models\Setting;

class SettingsTableSeeder extends Seeder
{
    /**
     * Auto generated seed file.
     */
    public function run()
    {
        $setting = $this->findSetting('site.title');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => __('voyager::seeders.settings.site.title'),
                'value'        => 'DFM VR',
                'details'      => '',
                'type'         => 'text',
                'order'        => 1,
                'group'        => 'Site',
            ])->save();
        }

        $setting = $this->findSetting('site.description');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => __('voyager::seeders.settings.site.description'),
                'value'        => 'DFM VR',
                'details'      => '',
                'type'         => 'text',
                'order'        => 2,
                'group'        => 'Site',
            ])->save();
        }

        $setting = $this->findSetting('site.logo');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => __('voyager::seeders.settings.site.logo'),
                'value'        => '',
                'details'      => '',
                'type'         => 'image',
                'order'        => 3,
                'group'        => 'Site',
            ])->save();
        }

        $setting = $this->findSetting('site.google_analytics_tracking_id');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => __('voyager::seeders.settings.site.google_analytics_tracking_id'),
                'value'        => '',
                'details'      => '',
                'type'         => 'text',
                'order'        => 4,
                'group'        => 'Site',
            ])->save();
        }

        $setting = $this->findSetting('admin.bg_image');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => __('voyager::seeders.settings.admin.background_image'),
                'value'        => '',
                'details'      => '',
                'type'         => 'image',
                'order'        => 5,
                'group'        => 'Admin',
            ])->save();
        }

        $setting = $this->findSetting('admin.title');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => __('voyager::seeders.settings.admin.title'),
                'value'        => 'DFM VR',
                'details'      => '',
                'type'         => 'text',
                'order'        => 1,
                'group'        => 'Admin',
            ])->save();
        }

        $setting = $this->findSetting('admin.description');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => __('voyager::seeders.settings.admin.description'),
                'value'        => 'DFM VR',
                'details'      => '',
                'type'         => 'text',
                'order'        => 2,
                'group'        => 'Admin',
            ])->save();
        }

        $setting = $this->findSetting('admin.loader');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => __('voyager::seeders.settings.admin.loader'),
                'value'        => '',
                'details'      => '',
                'type'         => 'image',
                'order'        => 3,
                'group'        => 'Admin',
            ])->save();
        }

        $setting = $this->findSetting('admin.icon_image');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => __('voyager::seeders.settings.admin.icon_image'),
                'value'        => '',
                'details'      => '',
                'type'         => 'image',
                'order'        => 4,
                'group'        => 'Admin',
            ])->save();
        }

        $setting = $this->findSetting('admin.google_analytics_client_id');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => __('voyager::seeders.settings.admin.google_analytics_client_id'),
                'value'        => '',
                'details'      => '',
                'type'         => 'text',
                'order'        => 1,
                'group'        => 'Admin',
            ])->save();
        }

        $setting = $this->findSetting('site.email');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => "Email contact",
                'value'        => 'contact@dfm-engineering.com',
                'details'      => '',
                'type'         => 'text',
                'order'        => 5,
                'group'        => 'Site',
            ])->save();
        }
        $setting = $this->findSetting('site.email_en');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => "Email contact En",
                'value'        => 'contact@dfm-en.com',
                'details'      => '',
                'type'         => 'text',
                'order'        => 6,
                'group'        => 'Site',
            ])->save();
        }
        $setting = $this->findSetting('site.email_fr');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => "Email contact Fr",
                'value'        => 'contact@dfm-fr.com',
                'details'      => '',
                'type'         => 'text',
                'order'        => 7,
                'group'        => 'Site',
            ])->save();
        }
        $setting = $this->findSetting('site.tel');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => "TelePhone",
                'value'        => '+84-02837158010',
                'details'      => '',
                'type'         => 'text',
                'order'        => 8,
                'group'        => 'Site',
            ])->save();
        }
        $setting = $this->findSetting('site.tel_en');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => "TelePhone EN",
                'value'        => '+en-02837158010',
                'details'      => '',
                'type'         => 'text',
                'order'        => 9,
                'group'        => 'Site',
            ])->save();
        }
        $setting = $this->findSetting('site.tel_fr');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => "TelePhone FR",
                'value'        => '+fr-02837158010',
                'details'      => '',
                'type'         => 'text',
                'order'        => 10,
                'group'        => 'Site',
            ])->save();
        }
        $setting = $this->findSetting('site.address');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => "Address",
                'value'        => 'DFM-Engineering, Tòa nhà Helios, Công viện phần mềm Quang Trung, Quận 12, TP HCM',
                'details'      => '',
                'type'         => 'text',
                'order'        => 11,
                'group'        => 'Site',
            ])->save();
        }
        $setting = $this->findSetting('site.address_en');
        if (!$setting->exists or true) {
            $setting->fill([
                'display_name' => "Address EN",
                'value'        => 'DFM-Engineering, Text_en, TP HCM',
                'details'      => '',
                'type'         => 'text',
                'order'        => 12,
                'group'        => 'Site',
            ])->save();
        }
        $setting = $this->findSetting('site.address_fr');
        if (!$setting->exists or true) {
            $setting->fill([
                'display_name' => "Address FR",
                'value'        => 'DFM-Engineering, Text_Fr, TP HCM',
                'details'      => '',
                'type'         => 'text',
                'order'        => 13,
                'group'        => 'Site',
            ])->save();
        }
        $setting = $this->findSetting('site.banner');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => "Banner",
                'value'        => '',
                'details'      => '',
                'type'         => 'image',
                'order'        => 14,
                'group'        => 'Site',
            ])->save();
        }
        $setting = $this->findSetting('site.youtube');
        if (!$setting->exists) {
            $setting->fill([
                'display_name' => "Youtube",
                'value'        => 'https://www.youtube.com/watch?v=1Px52FAa6t4&list=PL-20ryFWX0qoAOLOazYmVMa8yqWGJK2Iv',
                'details'      => '',
                'type'         => 'text',
                'order'        => 15,
                'group'        => 'Site',
            ])->save();
        }
    }

    /**
     * [setting description].
     *
     * @param [type] $key [description]
     *
     * @return [type] [description]
     */
    protected function findSetting($key)
    {
        return Setting::firstOrNew(['key' => $key]);
    }
}
