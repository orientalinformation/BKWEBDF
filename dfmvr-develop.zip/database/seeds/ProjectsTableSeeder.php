<?php

use Illuminate\Database\Seeder;
use TCG\Voyager\Models\DataRow;
use TCG\Voyager\Models\DataType;
use TCG\Voyager\Models\Menu;
use TCG\Voyager\Models\MenuItem;
use TCG\Voyager\Models\Permission;

class ProjectsTableSeeder extends Seeder
{
    /**
     * Auto generated seed file.
     *
     * @return void
     */
    public function run()
    {
        $env = app()->environment();

        if ($env == 'local'){
            $this->createData();
        }

        //Data Type
        $dataType = $this->dataType('slug', 'projects');
//        if (!$dataType->exists) {
            $dataType->fill([
                'name'                  => 'projects',
                'display_name_singular' => 'Project',
                'display_name_plural'   => 'Projects',
                'icon'                  => 'voyager-new',
                'model_name'            => 'App\\Models\\Project',
                'controller'            => 'App\\Http\\Controllers\\Admin\\ProjectController',
                'generate_permissions'  => 1,
                'description'           => '',
            ])->save();
//        }

        //Data Rows
        $projectDataType = DataType::where('slug', 'projects')->firstOrFail();
        $dataRow = $this->dataRow($projectDataType, 'id');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'number',
                'display_name' => __('voyager::seeders.data_rows.id'),
                'required'     => 1,
                'browse'       => 0,
                'read'         => 0,
                'edit'         => 0,
                'add'          => 0,
                'delete'       => 0,
                'order'        => 1,
            ])->save();
        }

        $dataRow = $this->dataRow($projectDataType, 'category_id');
        if (!$dataRow->exists or true) {
            $dataRow->fill([
                'type'         => 'hidden',
                'display_name' => __('voyager::seeders.data_rows.category'),
                'required'     => 1,
                'browse'       => 0,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 0,
                'details'      => [
                    'relationship' => [
                        'key'   => 'id',
                        'label' => 'name',
                    ],
                ],
                'order'        => 2,
            ])->save();
        }

        $dataRow = $this->dataRow($projectDataType, 'title');
        if (!$dataRow->exists or true) {
            $dataRow->fill([
                'type'         => 'text',
                'display_name' => __('voyager::seeders.data_rows.title'),
                'required'     => 1,
                'browse'       => 1,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'details'      => [
                    'validation' => [
                        'rule'  => 'required',
                    ],
                ],
                'order'        => 3,
            ])->save();
        }

        $dataRow = $this->dataRow($projectDataType, 'description');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'text_area',
                'display_name' => 'Description',
                'required'     => 0,
                'browse'       => 0,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'order'        => 4,
            ])->save();
        }

        $dataRow = $this->dataRow($projectDataType, 'content');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'rich_text_box',
                'display_name' => 'Content',
                'required'     => 1,
                'browse'       => 0,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'order'        => 5,
            ])->save();
        }

        $dataRow = $this->dataRow($projectDataType, 'slug');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'text',
                'display_name' => __('voyager::seeders.data_rows.slug'),
                'required'     => 1,
                'browse'       => 0,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'details'      => [
                    'slugify' => [
                        'origin'      => 'title'
                    ],
                    'validation' => [
                        'rule'  => 'unique:projects,slug',
                    ],
                ],
                'order' => 6,
            ])->save();
        }

        $dataRow = $this->dataRow($projectDataType, 'status');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'select_dropdown',
                'display_name' => __('voyager::seeders.data_rows.status'),
                'required'     => 1,
                'browse'       => 1,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'details'      => [
                    'default' => 'INACTIVE',
                    'options' => [
                        'INACTIVE' => 'INACTIVE',
                        'ACTIVE'   => 'ACTIVE',
                    ],
                ],
                'order' => 7,
            ])->save();
        }

        $dataRow = $this->dataRow($projectDataType, 'created_at');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'timestamp',
                'display_name' => __('voyager::seeders.data_rows.created_at'),
                'required'     => 1,
                'browse'       => 1,
                'read'         => 1,
                'edit'         => 0,
                'add'          => 0,
                'delete'       => 0,
                'order'        => 8,
            ])->save();
        }

        $dataRow = $this->dataRow($projectDataType, 'updated_at');
        if (!$dataRow->exists) {
            $dataRow->fill([
                'type'         => 'timestamp',
                'display_name' => __('voyager::seeders.data_rows.updated_at'),
                'required'     => 1,
                'browse'       => 0,
                'read'         => 0,
                'edit'         => 0,
                'add'          => 0,
                'delete'       => 0,
                'order'        => 9,
            ])->save();
        }

        $dataRow = $this->dataRow($projectDataType, 'image');
        if (!$dataRow->exists or true) {
            $dataRow->fill([
                'type'         => 'image',
                'display_name' => 'Image',
                'required'     => 0,
                'browse'       => 1,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 1,
                'details'      => [
                    "thumbnails"=> [
                        [
                            "name"=>"cropped",
                            "crop"=> [
                                "width"=> "420",
                                "height"=> "220"
                            ]
                        ]
                    ]
                ],
                'order'        => 10,
            ])->save();
        }

        $dataRow = $this->dataRow($projectDataType, 'project_belongstomany_project_category_relationship');
        if (!$dataRow->exists or true) {
            $dataRow->fill([
                'type'         => 'relationship',
                'display_name' => 'Project Category',
                'required'     => 1,
                'browse'       => 0,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 0,
                'details'      => [
                    "model"       => "\\App\\Models\\ProjectCategory",
                    "table"       => "project_categories",
                    "type"        => "belongsToMany",
                    "column"      => "id",
                    "key"         => "id",
                    "label"       => "name",
                    "pivot_table" => "project_project_categories",
                    "pivot"       => "1",
                    "taggable"    => "0"
                ],
                'order'        => 11,
            ])->save();
        }

        $dataRow = $this->dataRow($projectDataType, 'project_belongstomany_tag_relationship');
        if (!$dataRow->exists or true) {
            $dataRow->fill([
                'type'         => 'relationship',
                'display_name' => 'Tag',
                'required'     => 1,
                'browse'       => 0,
                'read'         => 1,
                'edit'         => 1,
                'add'          => 1,
                'delete'       => 0,
                'details'      => [
                    "model"       => "\\App\\Models\\Tag",
                    "table"       => "tags",
                    "type"        => "belongsToMany",
                    "column"      => "id",
                    "key"         => "id",
                    "label"       => "tag",
                    "pivot_table" => "project_tags",
                    "pivot"       => "1",
                    "taggable"    => "on"
                ],
                'order'        => 12,
            ])->save();
        }


        //Menu Item
        $menu = Menu::where('name', 'admin')->firstOrFail();
        $projectsMenuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => 'Projects',
            'url'     => '',
            'route'   => null
        ]);
        $menuItem = MenuItem::firstOrNew([
            'menu_id' => $menu->id,
            'title'   => 'List',
            'url'     => '/admin/projects',
            'route'   => 'voyager.projects.index',
        ]);
        if (!$menuItem->exists) {
            $menuItem->fill([
                'target'     => '_self',
                'icon_class' => 'voyager-documentation',
                'color'      => null,
                'parent_id'  => $projectsMenuItem->id,
                'order'      => 1,
            ])->save();
        }

        //Permissions
        Permission::generateFor('projects');

    }

    /**
     * [dataRow description].
     *
     * @param [type] $type  [description]
     * @param [type] $field [description]
     *
     * @return [type] [description]
     */
    protected function dataRow($type, $field)
    {
        return DataRow::firstOrNew([
                'data_type_id' => $type->id,
                'field'        => $field,
            ]);
    }

    /**
     * [dataType description].
     *
     * @param [type] $field [description]
     * @param [type] $for   [description]
     *
     * @return [type] [description]
     */
    protected function dataType($field, $for)
    {
        return DataType::firstOrNew([$field => $for]);
    }

    protected function createData()
    {
        //Content
        $faker = \Faker\Factory::create();

        for($i=1;$i<10;$i++){
            $page = \App\Models\Project::firstOrNew([
                'slug' => 'content-project-'.$i,
            ]);
            if (!$page->exists or true) {
                $page->fill([
                    'category_id' => 1,
                    'title'       => 'Hello World Project '.$i,
                    'description' => $faker->text,
                    'content'     => '<p>'.$faker->text.'</p>',
                    'image'       => '',
                    'status'      => 'ACTIVE',
                ])->save();
            }
        }
    }
}
