<?php

use App\Models\ServiceModel;
use App\Models\Service;

use Illuminate\Support\Str;
use Faker\Generator as Faker;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/

$factory->define(ServiceModel::class, function (Faker $faker) {
    return [
        'service_id' => Service::all()->random()->id,
        'list_features' => json_encode(["value" => [$faker->title]]),
        'title' => $faker->title,
        'description' => $faker->title,
        'link' => '/project',
        'status' => 'ACTIVE'
    ];
});
